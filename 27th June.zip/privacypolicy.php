<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover">
    <title>Privacy Policy | Cha A Chumuk</title>
    <link rel="icon" type="image/x-icon" href="favicon.ico">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@700&family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
    <style>
        :root { --primary: #ff9f1c; --primary-grad: linear-gradient(135deg, #ff9f1c 0%, #ff5e00 100%); --bg: #f8f9fa; --danger: #ff4757; --success: #2e7d32; --blue-accent: #5d87d6; }
        * { box-sizing: border-box; margin: 0; padding: 0; -webkit-tap-highlight-color: transparent; }
        body { font-family: 'Poppins', sans-serif; background: var(--bg); color: #333; overflow-x: hidden; }

        /* HEADER UI */
        .home-header { background: var(--primary-grad); padding: 30px 20px 20px 20px; color: white; border-radius: 0 0 35px 35px; position: fixed; top: 0; left: 0; width: 100%; z-index: 998; box-shadow: 0 4px 15px rgba(0,0,0,0.1); display: flex; align-items: center; gap: 15px; }
        .back-btn { background: rgba(255,255,255,0.2); width: 38px; height: 38px; border-radius: 50%; display: flex; align-items: center; justify-content: center; border: 1px solid white; color: white; cursor: pointer; text-decoration: none; transition: 0.2s; }
        .back-btn:active { transform: scale(0.9); }
        .header-title { font-family: 'Montserrat', sans-serif; font-size: 18px; font-weight: 700; }

        /* CONTENT UI */
        .page-content { padding-top: 110px; padding-bottom: 40px; }
        .card { background: white; border-radius: 20px; padding: 25px; margin: 15px; box-shadow: 0 4px 12px rgba(0,0,0,0.05); position: relative; }
        
        /* TYPOGRAPHY */
        h2 { font-size: 20px; color: var(--primary); margin-bottom: 15px; font-family: 'Montserrat', sans-serif; text-align: center; }
        h3 { font-size: 15px; color: #222; margin-top: 20px; margin-bottom: 8px; font-weight: 600; }
        p, li { font-size: 13px; color: #555; line-height: 1.7; margin-bottom: 10px; }
        ul { padding-left: 20px; margin-bottom: 15px; }
        li { margin-bottom: 5px; }
        .last-updated { text-align: center; font-size: 11px; color: #999; margin-bottom: 20px; font-weight: 600; text-transform: uppercase; letter-spacing: 1px; }
        
        hr { border: none; border-top: 1px dashed #eee; margin: 20px 0; }
    </style>
</head>
<body>

    <!-- STICKY HEADER -->
    <div class="home-header">
        <a href="javascript:history.back()" class="back-btn"><i class="fas fa-arrow-left"></i></a>
        <div style="display:flex; align-items:center; gap:12px;">
            <img src="logo.png" alt="Logo" style="width:35px; border-radius:50%; background:white; padding: 2px;">
            <div class="header-title">Cha A Chumuk</div>
        </div>
    </div>

    <div class="page-content">
        <div class="card">
            <h2>Privacy Policy</h2>
            <div class="last-updated">Last Updated: May 2026</div>

            <p>Welcome to <b>Cha A Chumuk</b>. We value your privacy and are committed to protecting your personal data. This Privacy Policy explains how we collect, use, and safeguard your information when you use our web application to order food and snacks.</p>

            <h3>1. Information We Collect</h3>
            <p>To provide you with a seamless food delivery experience, we collect the following types of information:</p>
            <ul>
                <li><b>Personal Information:</b> Full Name, Mobile Number, Email Address, Age, Gender, and Profile Avatar (if provided via Google Login or manual input).</li>
                <li><b>Location Data:</b> Real-time GPS location and pinned addresses to accurately calculate delivery distance (up to 15km) and route delivery partners.</li>
                <li><b>Order History:</b> Details of the items you order, subtotal, delivery charges, and feedback surveys.</li>
            </ul>

            <h3>2. How We Use Your Information</h3>
            <p>We use the collected data strictly to operate and improve our services:</p>
            <ul>
                <li>To process and deliver your food orders accurately using OpenStreetMap and OSRM routing.</li>
                <li>To calculate dynamic delivery fees based on your exact road distance.</li>
                <li>To facilitate payments via Razorpay (for online transactions) or manage Cash on Delivery (COD).</li>
                <li>To send order updates, notifications, and delivery partner details.</li>
            </ul>

            <h3>3. Third-Party Services & Data Sharing</h3>
            <p>We do not sell your personal data. However, we share necessary information with trusted third-party providers:</p>
            <ul>
                <li><b>Firebase (Google):</b> For secure user authentication, database storage, and profile management.</li>
                <li><b>Razorpay:</b> For processing secure online payments. We do not store your credit card or UPI PIN data on our servers.</li>
                <li><b>Nominatim & Leaflet:</b> For mapping and geocoding your delivery address.</li>
            </ul>

            <h3>4. Data Security</h3>
            <p>Your data is securely stored using industry-standard encryption provided by Firebase. We implement stringent security measures to prevent unauthorized access to your account and personal details.</p>

            <h3>5. Your Rights</h3>
            <p>You have full control over your data. You can update your profile details, edit/delete saved addresses, or logout at any time from the "Profile" section of the app. If you wish to completely delete your account, please contact our support.</p>

            <hr>
            <p style="text-align: center; font-weight: 600; color: #888;">For privacy-related queries, reach out to us via the "Get in Touch" section in the app.</p>
        </div>
    </div>

    <script>
        // Haptic feedback for back button
        document.querySelector('.back-btn').addEventListener('touchstart', function() {
            if (navigator.vibrate) navigator.vibrate(40);
        }, { passive: true });
    </script>
</body>
</html>