<?php require_once 'includes/config.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover">
    <title>Cha A Chumuk</title>
    <link rel="icon" type="image/x-icon" href="assets/images/favicon.ico?v=<?= filemtime('assets/images/favicon.ico') ?>">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@700&family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
    <script src="https://checkout.razorpay.com/v1/checkout.js"></script>
    <script src="https://maps.googleapis.com/maps/api/js?key=<?php echo GOOGLE_MAPS_API_KEY; ?>&libraries=places"></script>
    <!-- Cache‑busting for local CSS -->
    <link rel="stylesheet" href="assets/css/style.css?v=<?= filemtime('assets/css/style.css') ?>">
</head>
<body>

    <!-- ANIMATOR -->
    <div id="loader-wrapper">
        <div class="loader-pattern"></div><div class="loader-glow"></div>
        <div class="streak" style="top:40%; width:80px; animation-delay:0s"></div>
        <div class="streak" style="top:55%; width:120px; animation-delay:0.1s"></div>
        <div class="streak" style="top:65%; width:60px; animation-delay:0.2s"></div>
        <div class="anim-container"><div id="anim-area"><img src="assets/images/logo.png" id="anim-asset"></div>
            <div id="welcome-text">Welcome to Cha a chumuk<br><span class="designer-credit">Food delivery app designed by Subhajit Bera</span></div>
        </div>
    </div>

    <!-- INLINE LOADER SCRIPT (must run immediately) -->
    <script>
        (function() {
            const icons = ['assets/images/logo.png', 'fa-solid fa-burger', 'assets/images/logo.png', 'fa-solid fa-pizza-slice', 'assets/images/logo.png', 'fa-solid fa-mug-hot'];
            let iconIdx = 0;
            const assetEl = document.getElementById('anim-area');
            const toggleInterval = setInterval(() => {
                iconIdx = (iconIdx + 1) % icons.length;
                if (icons[iconIdx].includes('.png')) {
                    assetEl.innerHTML = `<img src="${icons[iconIdx]}" id="anim-asset">`;
                } else {
                    assetEl.innerHTML = `<i class="${icons[iconIdx]}" id="anim-asset"></i>`;
                }
            }, 500);
            setTimeout(() => {
                clearInterval(toggleInterval);
                assetEl.style.display = 'none';
                document.querySelectorAll('.streak').forEach(s => s.style.display = 'none');
                document.getElementById('welcome-text').style.display = 'block';
            }, 5000);

            window.finalUnlock = function() {
                const loader = document.getElementById('loader-wrapper');
                if (loader) {
                    loader.style.opacity = '0';
                    setTimeout(() => {
                        loader.style.display = 'none';
                        setTimeout(window.triggerGlobalPromoPopup || function(){}, 5000);
                    }, 800);
                } else {
                    setTimeout(window.triggerGlobalPromoPopup || function(){}, 5000);
                }
            };
            setTimeout(window.finalUnlock, 6500);
        })();
    </script>

    <!-- REST OF THE HTML (same as before) -->
    <!-- MANDATORY LOGIN MODAL -->
    <div id="login-modal" class="modal-overlay" style="z-index: 100005;">
        <div class="contact-card" style="width: 90%; max-width: 350px;">
            <img src="assets/images/logo.png" style="width:80px; margin-bottom: 10px;">
            <h2 id="ui-login-title">Login</h2>
            <p style="font-size: 11px; color: #888; margin-bottom: 15px;">Please login to continue ordering delicious snacks!</p>
            <input type="email" id="l-email" placeholder="Email" class="form-input">
            <input type="password" id="l-pass" placeholder="Password" class="form-input" style="margin-bottom:15px;">
            <div id="login-error" style="color:var(--danger); font-size:12px; margin-bottom:10px; display:none; font-weight:600;"></div>
            <button id="ui-login-btn" class="btn-primary" onclick="login()">Login</button>
            <button onclick="googleLogin()" style="width:100%; padding:12px; margin-top:10px; border-radius:12px; border:1px solid #eee; background:white; display:flex; align-items:center; justify-content:center; gap:10px; cursor:pointer;"><img src="https://cdn-icons-png.flaticon.com/512/2991/2991148.png" width="16"> <span id="ui-google-login">Google Login</span></button>
            <p id="ui-new-user" style="margin-top:20px; font-size:13px; cursor: pointer; color: var(--primary);" onclick="switchAuthModal('signup')">New user? <b>Register</b></p>
        </div>
    </div>

    <!-- MANDATORY REGISTRATION MODAL -->
    <div id="signup-modal" class="modal-overlay" style="z-index: 100005;">
        <div class="contact-card" style="width: 90%; max-width: 350px;">
            <h3 id="ui-reg-title">Register</h3>
            <p style="font-size: 11px; color: #888; margin-bottom: 10px;">Fields marked with * are mandatory</p>
            <input type="text" id="r-name" placeholder="Full Name *" class="form-input">
            <input type="tel" id="r-phone" placeholder="Mobile Number *" class="form-input">
            <input type="password" id="r-pass" placeholder="New Password *" class="form-input">
            <input type="email" id="r-email" placeholder="Email (Optional)" class="form-input" style="margin-bottom:15px;">
            <button id="ui-reg-btn" class="btn-primary" onclick="register()">Create Account</button>
            <button onclick="switchAuthModal('login')" style="width:100%; margin-top:15px; border:none; background:none; color:var(--primary); font-weight:600; font-size:14px;">Already have an account? Login</button>
        </div>
    </div>

    <!-- SAVED ADDRESSES MODAL -->
    <div id="saved-addr-modal" class="bottom-sheet" style="z-index: 100003;">
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:15px;">
            <h3 id="ui-modal-saved-title" style="font-size:18px;">Saved Addresses</h3>
            <button onclick="closeSavedAddressesModal()" style="border:none; background:none; font-size:20px; color:#888;"><i class="fas fa-times"></i></button>
        </div>
        <div id="saved-addr-list-container" style="max-height: 50vh; overflow-y: auto; padding-right: 5px; margin-bottom: 15px;">
            <!-- Addresses injected here -->
        </div>
    </div>

    <!-- LANGUAGE SELECTOR MODAL -->
    <div id="lang-modal" class="modal-overlay" style="z-index: 100006;">
        <div class="contact-card" style="width: 90%; max-width: 320px;">
            <h3 style="margin-bottom: 5px; font-size: 18px;">Select Language</h3>
            <p style="font-size: 12px; color: #888; margin-bottom: 20px;">ভাষা নির্বাচন করুন</p>
            <div style="display:flex; flex-direction:column; gap:10px; margin-bottom:15px;">
                <div class="pay-opt" id="lang-opt-en" onclick="selectLangOpt('en')">English</div>
                <div class="pay-opt" id="lang-opt-bn" onclick="selectLangOpt('bn')">বাংলা (Bengali)</div>
            </div>
            <button class="btn-primary" onclick="applyLang()">Set Language</button>
            <button onclick="closeLangModal()" style="width:100%; margin-top:10px; border:none; background:none; color:#888; font-weight:600;">Cancel / বাতিল</button>
        </div>
    </div>

    <!-- STICKY HEADER GLOBAL -->
    <div id="global-header" class="home-header">
        <div class="header-actions">
            <div class="contact-btn" onclick="openContact()"><i class="fas fa-headset"></i></div>
            <div class="lang-container" onclick="openLangModal()">
                <i class="fas fa-globe"></i>
                <span id="ui-current-lang-text" style="font-weight:600; font-size:11px; margin-left:3px;">EN</span>
            </div>
        </div>
        <div style="display:flex; align-items:center; gap:15px;">
            <img src="assets/images/logo.png" style="width:40px; border-radius:50%; background:white;">
            <div><h2 style="font-size:18px;">Cha A Chumuk</h2><span id="welcome-user-span" style="font-size:10px; opacity:0.8;">Welcome, Guest!</span></div>
        </div>
        
        <div class="search-wrapper">
            <div class="search-bar">
                <i class="fas fa-search anim-search-icon"></i>
                <input type="text" id="menu-search" placeholder="Search for snacks..." oninput="filterMenu(this.value)">
                <i class="fas fa-times" style="cursor:pointer;" onclick="document.getElementById('menu-search').value=''; filterMenu('');"></i>
            </div>
        </div>
    </div>

    <!-- CONTACT MODAL -->
    <div id="contact-modal" class="modal-overlay" onclick="closeContact()">
        <div class="contact-card" onclick="event.stopPropagation()">
            <h3 id="ui-contact-title">Get in Touch</h3>
            <a href="tel:9903300610" class="contact-opt"><i class="fas fa-phone-alt" style="color:var(--success);"></i><span id="ui-call">Call Support</span></a>
            <a href="https://wa.me/919903300610" class="contact-opt"><i class="fab fa-whatsapp" style="color:#25D366;"></i><span id="ui-wa">WhatsApp Us</span></a>
            <button id="ui-close" onclick="closeContact()" style="margin-top:10px; border:none; background:none; color:#888; font-weight:600;">Close</button>
        </div>
    </div>

    <!-- LOCATION PICKER SHEET -->
    <div id="location-overlay" class="modal-overlay" onclick="closeLocationPicker()"></div>
    <div id="location-sheet" class="bottom-sheet">
        <div class="loc-sheet-header" style="background: var(--primary-grad); margin: -20px -20px 15px -20px; padding: 20px; border-radius: 30px 30px 0 0; color: white;">
            <div style="text-align: center; width: 100%;">
                <i class="fas fa-map-marker-alt" style="font-size: 30px; margin-bottom: 10px;"></i>
                <h4 id="loc-title" style="justify-content: center;">Location Permission Required</h4>
                <p id="loc-subtext" style="font-size:11px; opacity:0.9; margin-top:5px; font-weight:400;">Granting location permission will ensure accurate address and hassle-free delivery.</p>
                <button id="loc-grant-btn" class="loc-grant-btn btn-primary" style="margin-top: 15px; width: auto; background: white; color: var(--primary); padding: 8px 20px; font-size: 13px; border-radius: 10px;" onclick="grantLocation()">Grant Permission</button>
            </div>
        </div>
    </div>

    <div id="detail-overlay" class="modal-overlay" onclick="closeDetails()"></div>
    <div id="item-sheet" class="bottom-sheet">
        <img id="sheet-img" src="" class="sheet-img">
        <h2 id="sheet-name">Item Name</h2>
        <p id="sheet-price" style="color:var(--primary); font-weight:700; font-size:18px; margin-bottom:20px;">₹0</p>
        <button id="ui-sheet-add" class="btn-primary" onclick="addFromSheet()">Add to Bucket</button>
        <button id="ui-sheet-close" onclick="closeDetails()" style="width:100%; margin-top:10px; border:none; background:none; color:#aaa; font-size:13px;">Dismiss</button>
    </div>

    <div class="page-content">
        <!-- HOME -->
        <div id="home-page" class="page active">
            <div id="banner-section" class="banner-container">
                <div id="banner-track" class="banner-track"></div>
            </div>
            <div id="menu-container" style="padding-top:10px;"></div>
        </div>

        <!-- ORDERS -->
        <div id="orders-page" class="page"><h2 id="ui-orders-title" style="margin: 20px;">My Orders</h2><div id="active-orders" style="padding:10px;"></div><div style="text-align:center;"><button id="ui-view-past" class="btn-primary" style="width:auto; padding:8px 25px; font-size:12px; background:#666;" onclick="toggleHistory()">View Past Orders</button></div><div id="history-section" style="display:none; padding:10px;"><div id="history-orders"></div></div></div>
        
        <!-- PROFILE -->
        <div id="profile-page" class="page">
            <h2 id="ui-profile-title" style="margin: 20px;">Profile Settings</h2>
            <div style="margin-top: 10px;">
                <div id="user-initials" class="user-initials">?</div>
                <p id="ui-prof-pdet" class="profile-section-title">Personal Details</p>
                <div class="prof-group">
                    <div class="prof-row"><div class="prof-icon"><i class="fas fa-user"></i></div><div class="prof-content"><label class="prof-label" id="lbl-pname">Full Name</label><input id="p-name" class="prof-input" readonly></div><i class="fas fa-pen prof-edit" onclick="enableEdit('p-name')"></i></div>
                    <div class="prof-row"><div class="prof-icon"><i class="fas fa-phone-alt"></i></div><div class="prof-content"><label class="prof-label" id="lbl-pphone">Mobile Number</label><input id="p-phone" class="prof-input" readonly></div><i class="fas fa-pen prof-edit" onclick="enableEdit('p-phone')"></i></div>
                    <div class="prof-row"><div class="prof-icon"><i class="fas fa-birthday-cake"></i></div><div class="prof-content"><label class="prof-label" id="lbl-page">Age</label><input id="p-age" class="prof-input" readonly></div><i class="fas fa-pen prof-edit" onclick="enableEdit('p-age')"></i></div>
                    <div class="prof-row"><div class="prof-icon"><i class="fas fa-venus-mars"></i></div><div class="prof-content"><label class="prof-label" id="lbl-pgen">Gender</label><select id="p-gender" class="prof-input" disabled><option value="Male">Male</option><option value="Female">Female</option></select></div><i class="fas fa-pen prof-edit" onclick="enableEdit('p-gender')"></i></div>
                </div>
                <p id="ui-prof-loc" class="profile-section-title">Delivery Location</p>
                <div class="prof-group" style="padding: 15px 20px;">
                    <button id="ui-prof-manage-addr" class="btn-primary" style="background: var(--blue-accent); font-size: 13px;" onclick="openSavedAddressesModal('profile')"><i class="fas fa-map-marked-alt"></i> Manage Saved Addresses</button>
                </div>
                <div style="padding: 0 15px;"><button id="ui-update-btn" class="btn-primary" onclick="saveProfile()">Update Profile</button></div>
                <div class="logout-card" onclick="auth.signOut()"><i class="fas fa-sign-out-alt"></i><span id="ui-logout-btn-text">Logout from Account</span></div>
                
                <div style="text-align:center; padding: 25px 20px; font-size: 11px; color: #888; line-height: 1.6; border-top: 1px solid #eee; margin-top: 20px;">
                    You're now part of our family—by using our services, you agree to our<br>
                    <a href="https://chaachumuk.com/termsofuse.php" style="color:var(--primary); font-weight:600; text-decoration:none;">Terms & Conditions</a> and 
                    <a href="https://chaachumuk.com/privacypolicy.php" style="color:var(--primary); font-weight:600; text-decoration:none;">Privacy Policy</a>.
                </div>
            </div>
        </div>
        
        <!-- BUCKET -->
        <div id="cart-page" class="page"><h2 id="ui-bucket-title" style="margin: 20px;">Bucket</h2><div id="bucket-items-list" class="card"></div><div class="card"><p id="lbl-fname" style="font-size:11px; font-weight:700; color:#888;">FULL NAME</p><input type="text" id="bucket-user-name" style="width:100%; padding:12px; border:1px solid #eee; border-radius:12px; margin-bottom:15px;"><p id="lbl-fphone" style="font-size:11px; font-weight:700; color:#888;">MOBILE NUMBER</p><input type="tel" id="bucket-phone" style="width:100%; padding:12px; border:1px solid #eee; border-radius:12px; margin-bottom:5px;" oninput="validateBucketPhone()"><div id="bucket-phone-warning" style="display:none; color:var(--danger); font-size:11px; margin-bottom:15px; font-weight:600;"></div><button id="ui-proceed-btn" class="btn-primary" disabled onclick="proceedToCheckout()">Proceed to Delivery</button></div></div>

        <!-- CHECKOUT -->
        <div id="checkout-page" class="page">
            <h2 id="ui-checkout-title" style="margin: 20px;">Checkout</h2>
            <div class="card" id="checkout-summary"></div>
            
            <div class="card">
                <p id="lbl-addr" style="font-size:11px; font-weight:700; color:#888; margin-bottom: 10px;">DELIVERY ADDRESS</p>
                
                <div class="addr-options-row">
                    <div class="addr-opt-btn" id="ui-addr-curr" onclick="triggerLiveLocation()"><i class="fas fa-crosshairs"></i> Current Location</div>
                    <div class="addr-opt-btn" id="ui-addr-saved" onclick="openSavedAddressesModal('checkout')"><i class="fas fa-bookmark"></i> Saved Addresses</div>
                </div>

                <div style="position: relative; margin-bottom: 10px;">
                    <input type="text" id="checkout-addr-text" class="form-input" placeholder="Search address within 25km..." style="padding-right:35px; margin-bottom:0;">
                    <i class="fas fa-times" style="position:absolute; right:12px; top:16px; color:#aaa; cursor:pointer;" onclick="document.getElementById('checkout-addr-text').value='';"></i>
                    <div id="checkout-addr-loader" class="loading-overlay" style="display:none;"><i class="fas fa-spinner fa-spin" style="margin-right: 6px;"></i> Mapping...</div>
                </div>

                <div class="live-map-container">
                    <div id="checkout-map" class="live-map"></div>
                    <div id="checkout-map-loader" class="loading-overlay" style="display:none;"><i class="fas fa-spinner fa-spin" style="margin-right: 6px;"></i> Map Loading...</div>
                    <button class="locate-btn" onclick="triggerLiveLocation()"><i class="fas fa-location-arrow"></i></button>
                </div>
                
                <button class="btn-add" style="margin-top: 10px; width: 100%; justify-content: center; padding: 12px; font-size: 13px;" onclick="saveCurrentCheckoutAddress()"><i class="fas fa-save"></i> Save this Address</button>

                <div id="delivery-info-box" style="margin-top:15px; padding:15px; background:#fff; border:1px solid #eee; border-radius:15px; font-size:13px;">
                    <div style="display:flex; justify-content:space-between; margin-bottom:8px;"><span id="ui-dist">Road Distance</span><b id="checkout-dist-val">...</b></div>
                    <div id="delivery-details-block" style="display:none;">
                        <div style="display:flex; justify-content:space-between; margin-bottom:8px; color:#666;"><span id="ui-min">Min. Order Required</span><b id="checkout-min-val">₹0</b></div>
                        <div style="display:flex; justify-content:space-between; margin-bottom:8px; color:var(--success);"><span id="ui-fee">Delivery Fee</span><b id="checkout-del-fee">₹0</b></div>
                        
                        <hr style="border:none; border-top:1px dashed #eee; margin:10px 0;">
                        
                        <!-- PROMO CODE SECTION -->
                        <div style="display:flex; gap:10px; margin-bottom:10px;">
                            <input type="text" id="promo-input-box" placeholder="Have a promocode?" style="flex:1; border:1px solid #ddd; padding:8px 12px; border-radius:8px; outline:none; text-transform:uppercase; font-size:12px; font-family:inherit;">
                            <button id="btn-apply-promo" class="btn-primary" style="width:auto; padding:8px 15px; font-size:12px; border-radius:8px;" onclick="applyPromoCode()">Apply</button>
                        </div>
                        <div id="promo-msg" style="font-size:11px; margin-bottom:10px; font-weight:600;"></div>

                        <div id="promo-display-row" style="display:none; justify-content:space-between; margin-bottom:8px; color:var(--success);"><span>&#127881; Promo Discount</span><b id="promo-discount-val">-₹0</b></div>
                        <div style="display:flex; justify-content:space-between; font-size:18px; font-weight:700; color:var(--primary);"><span id="ui-tot">Total Pay</span><b id="checkout-total-pay">...</b></div>
                    </div>
                </div>
                
                <div id="shop-closed-warning" style="display:none; margin-top:10px; color:var(--danger); font-weight:600; text-align:center; padding:10px; background:#fff3cd; border-radius:10px;">
                    <i class="fas fa-clock"></i> Shop is closed. Operational hours: <span id="shop-timings-display"></span>.
                </div>
                <div id="distance-error" style="display:none; color:var(--danger); font-weight:600; text-align:center; padding:10px;">We don't deliver here (Max 15km) or Invalid Location</div>
                <div id="min-order-error" style="display:none; color:var(--danger); font-size:11px; text-align:center; margin-top:10px; font-weight:600;">Low order value for this distance!</div>
            </div>

            <div class="card">
                <p style="font-size:11px; font-weight:700; color:#888; margin-bottom: 10px;">PAYMENT METHOD</p>
                <div class="pay-methods">
                    <div class="pay-opt active" id="pay-online" onclick="selectPay('online')">
                        <i class="fas fa-credit-card"></i> Online Payment
                    </div>
                    <div class="pay-opt" id="pay-cod" onclick="selectPay('cod')">
                        <i class="fas fa-money-bill-wave"></i> Cash on Delivery
                    </div>
                </div>
                <button id="payment-btn" class="btn-primary" style="margin-top:10px; display:none;" disabled onclick="processPaymentAction()">Make Payment</button>
            </div>
        </div>

        <!-- PAYMENT STATUS -->
        <div id="payment-success-page" class="page status-page"><div class="status-icon" style="color:var(--success);"><i class="fas fa-check-circle"></i></div><h2 id="ui-pay-ok">Payment Successful!</h2><button class="btn-primary" onclick="showPage('orders-page')" id="ui-back-ord1">Back to Orders</button></div>
        <div id="payment-fail-page" class="page status-page"><div class="status-icon" style="color:var(--danger);"><i class="fas fa-times-circle"></i></div><h2 id="ui-pay-fail">Payment Failed</h2><button class="btn-primary" onclick="showPage('orders-page')" id="ui-back-ord2">Back to Orders</button></div>
        <div id="cod-success-page" class="page status-page"><div class="status-icon" style="color:var(--primary);"><i class="fas fa-clipboard-check"></i></div><h2>Order Placed!</h2><p style="font-size: 13px; color: #666; margin-bottom: 20px;">Pay via cash or UPI at the time of delivery.</p><button class="btn-primary" onclick="showPage('orders-page')">Track Order</button></div>
    </div>

    <!-- GLOBAL PROMO POPUP BANNER -->
    <div id="promo-popup-overlay" style="display:none; position:fixed; inset:0; background:rgba(0,0,0,0.7); z-index:200000; align-items:center; justify-content:center; backdrop-filter: blur(5px);">
        <div style="position:relative; max-width:320px; width:90%; animation: popScale 0.4s cubic-bezier(0.17, 0.67, 0.83, 0.67);">
            <button onclick="closePromoPopup()" style="position:absolute; top:-15px; right:-15px; width:36px; height:36px; border-radius:50%; background:white; border:none; font-size:20px; font-weight:700; color:#333; cursor:pointer; z-index:1; box-shadow:0 4px 15px rgba(0,0,0,0.3); display:flex; align-items:center; justify-content:center;">&times;</button>
            <img id="promo-popup-img" src="" style="width:100%; border-radius:20px; display:block; box-shadow:0 15px 40px rgba(0,0,0,0.4);">
        </div>
    </div>

    <!-- BOTTOM NAV -->
    <nav class="bottom-nav" id="main-nav" style="display:none;">
        <div class="nav-item active" onclick="showPage('home-page', this)"><i class="fas fa-home"></i><span id="nav-home">Home</span></div>
        <div class="nav-item" onclick="showPage('orders-page', this)"><i class="fas fa-receipt"></i><span id="nav-orders">Orders</span></div>
        <div class="nav-item" onclick="showPage('profile-page', this)"><i class="fas fa-user-circle"></i><span id="nav-profile">Profile</span></div>
    </nav>

    <button id="floating-bucket" onclick="showPage('cart-page')"><i class="fas fa-shopping-basket" style="color:orange; font-size:24px;"></i><div id="bucket-badge" class="bucket-badge">0</div></button>

    <!-- Firebase and external scripts -->
    <script src="https://www.gstatic.com/firebasejs/9.17.1/firebase-app-compat.js"></script>
    <script src="https://www.gstatic.com/firebasejs/9.17.1/firebase-auth-compat.js"></script>
    <script src="https://www.gstatic.com/firebasejs/9.17.1/firebase-database-compat.js"></script>

    <!-- Local scripts with cache‑busting -->
    <script src="assets/js/firebase-init.js?v=<?= filemtime('assets/js/firebase-init.js') ?>"></script>
    <script src="assets/js/app.js?v=<?= filemtime('assets/js/app.js') ?>"></script>
</body>
</html>