<?php require_once 'includes/config.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Hub | Cha A Chumuk 3.0 Gold</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://maps.googleapis.com/maps/api/js?key=<?php echo GOOGLE_MAPS_API_KEY; ?>&libraries=places"></script>
    <!-- Cache‑busting for admin CSS -->
    <link rel="stylesheet" href="assets/css/admin.css?v=<?= filemtime('assets/css/admin.css') ?>">
</head>
<body>

<audio id="orderRinger" loop preload="auto"><source src="assets/audio/ringer.mp3" type="audio/mpeg"></audio>

<!-- LOADER -->
<div id="loader-wrapper">
    <div class="anim-container">
        <img src="assets/images/logo.png" id="anim-logo" onerror="this.src='https://cdn-icons-png.flaticon.com/512/3081/3081031.png'">
        <i class="fas fa-user-shield" id="anim-icon"></i>
    </div>
    <div style="margin-top:20px; font-weight:700; color:#222; text-transform:uppercase; letter-spacing:2px; font-size:13px;">Cha A Chumuk Admin</div>
</div>

<!-- INLINE LOADER SCRIPT (FIXED) -->
<script>
    (function() {
        let toggleCount = 0;
        const interval = setInterval(() => {
            const logo = document.getElementById('anim-logo');
            const icon = document.getElementById('anim-icon');
            if (!logo || !icon) return;
            toggleCount++;
        }, 100);
        setTimeout(() => {
            clearInterval(interval);
            const loader = document.getElementById('loader-wrapper');
            if (loader) {
                loader.style.opacity = '0';
                setTimeout(() => {
                    loader.style.display = 'none';
                    // **DO NOT** set login display here – let auth listener handle it.
                }, 800);
            }
        }, 3000);
    })();
</script>

<!-- LOGIN SCREEN -->
<div id="login-screen">
    <div class="login-card">
        <img src="assets/images/logo.png" width="85" style="margin-bottom:15px;" onerror="this.src='https://cdn-icons-png.flaticon.com/512/3081/3081031.png'">
        <h2>Admin Hub Login</h2>
        <p style="font-size:12px; color:#888; margin-bottom:30px;">Authorized Access Only</p>
        <div class="input-group"><label>Username</label><input type="text" id="adm-user" placeholder="Enter username"></div>
        <div class="input-group"><label>Security Password</label><input type="password" id="adm-pass" placeholder="••••••••"></div>
        <button class="btn-gold" onclick="attemptLogin()">Enter Command Center</button>
    </div>
</div>

<!-- MAIN ADMIN PANEL -->
<div id="admin-main">
    <div class="sidebar">
        <div class="sidebar-header">
            <img src="assets/images/logo.png" width="60" onerror="this.src='https://cdn-icons-png.flaticon.com/512/3081/3081031.png'">
            <p style="color:var(--primary); font-weight:700; font-size:14px; margin-top:10px;">ADMIN HUB 3.0</p>
        </div>
        <div class="nav-item active" onclick="showTab('kitchen', this)"><i class="fas fa-utensils"></i> Kitchen Hub</div>
        <div class="nav-item" onclick="showTab('analytics', this)"><i class="fas fa-chart-line"></i> Analytics</div>
        <div class="nav-item" onclick="showTab('history', this)"><i class="fas fa-history"></i> Sales History</div>
        <div class="nav-item" onclick="showTab('menu', this)"><i class="fas fa-list"></i> Menu Management</div>
        <div class="nav-item" onclick="showTab('drivers', this)"><i class="fas fa-motorcycle"></i> Driver Portal</div>
        <div class="nav-item" onclick="showTab('ads', this)"><i class="fas fa-ad"></i> Promos & Ads</div>
        <div class="nav-item" onclick="showTab('customers', this)"><i class="fas fa-users"></i> Customer Base</div>
        <a href="#" class="logout-btn" style="margin-top:auto; padding:20px; background:#c0392b; color:white; text-align:center; font-weight:700; text-decoration:none;" onclick="auth.signOut(); return false;">LOGOUT PANEL</a>
    </div>

    <div class="content">
        <!-- Kitchen Hub -->
        <div id="kitchen" class="section active">
            <div class="section-header" style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px;">
                <div style="display:flex; align-items:center; gap:15px;">
                    <h2 style="font-weight:700; margin:0;">Live Orders</h2>
                    <i class="fas fa-sync-alt" id="ref-icon" onclick="manualRefreshKitchen()" style="cursor:pointer; color:var(--primary); font-size:18px;"></i>
                </div>
                <div style="display:flex; align-items:center; gap:10px;">
                    <button class="btn-gold" style="width:auto; padding:10px 20px; background:var(--blue);" onclick="openManualOrderModal()"><i class="fas fa-plus"></i> Manual Order</button>
                    <div class="card" style="margin:0; padding:10px 20px; border:2px solid #eee; display:flex; align-items:center;">
                        <span style="font-size:11px; font-weight:700; margin-right:10px;">SHOP STATUS</span>
                        <label class="switch"><input type="checkbox" id="master-switch" onchange="db.ref('settings/is_open').set(this.checked)"><span class="slider"></span></label>
                    </div>
                </div>
            </div>

            <!-- Operating Timings -->
            <div class="card" style="margin-bottom:20px;">
                <h3 style="font-size:14px; margin-bottom:12px; color:var(--primary);"><i class="far fa-clock"></i> Operating Timings</h3>
                <div style="display:flex; gap:15px; align-items:flex-end;">
                    <div class="input-group" style="flex:1;"><label>Open Time</label><input type="time" id="open-time"></div>
                    <div class="input-group" style="flex:1;"><label>Close Time</label><input type="time" id="close-time"></div>
                    <div style="display:flex; align-items:center; gap:10px; margin-bottom:20px;">
                        <label class="switch"><input type="checkbox" id="auto-schedule-switch" onchange="db.ref('settings/auto_schedule').set(this.checked)"><span class="slider"></span></label>
                        <span style="font-size:11px; font-weight:700;">Auto Schedule</span>
                    </div>
                    <button class="btn-gold" style="width:auto; padding:12px 25px;" onclick="saveTimings()">Save Timings</button>
                </div>
                <small style="color:#888;">Auto-schedule updates the shop status automatically based on these timings.</small>
            </div>

            <div id="k-cont" style="display:grid; grid-template-columns: repeat(auto-fill, minmax(320px,1fr)); gap:20px;"></div>
        </div>

        <!-- Analytics -->
        <div id="analytics" class="section">
            <h2 style="font-weight:700; margin-bottom:15px;">Sales Analytics</h2>
            <div class="analytics-grid" style="display:grid; grid-template-columns:repeat(4,1fr); gap:15px; margin-bottom:20px;">
                <div class="stat-card"><span>Today</span><h3 id="s-daily">₹0</h3><small>Orders: <b id="cnt-daily" style="color:var(--primary)">0</b></small></div>
                <div class="stat-card"><span>Weekly</span><h3 id="s-weekly">₹0</h3><small>Orders: <b id="cnt-weekly" style="color:var(--primary)">0</b></small></div>
                <div class="stat-card"><span>Monthly</span><h3 id="s-monthly">₹0</h3><small>Orders: <b id="cnt-monthly" style="color:var(--primary)">0</b></small></div>
                <div class="stat-card"><span>Yearly</span><h3 id="s-yearly">₹0</h3><small>Orders: <b id="cnt-yearly" style="color:var(--primary)">0</b></small></div>
            </div>
            <div class="card" style="max-width:800px;"><canvas id="salesChart" height="250"></canvas></div>
        </div>

        <!-- History -->
        <div id="history" class="section">
            <h2 style="font-weight:700;">Transaction History</h2>
            <div class="card" style="overflow-x:auto; padding:0;">
                <table id="history-table" style="min-width:1700px;">
                    <thead>
                        <tr>
                            <th>Order ID<br><input type="text" class="filter-input" onkeyup="filterTable(0, this)" placeholder="ID.."></th>
                            <th>Date/Time<br><input type="text" class="filter-input" onkeyup="filterTable(1, this)" placeholder="Date.."></th>
                            <th>Customer<br><input type="text" class="filter-input" onkeyup="filterTable(2, this)" placeholder="Name.."></th>
                            <th>Items<br><input type="text" class="filter-input" onkeyup="filterTable(3, this)" placeholder="Items.."></th>
                            <th>Payment<br><input type="text" class="filter-input" onkeyup="filterTable(4, this)" placeholder="Type.."></th>
                            <th>Address<br><input type="text" class="filter-input" onkeyup="filterTable(5, this)" placeholder="Loc.."></th>
                            <th>Subtotal</th>
                            <th>Del. Fee</th>
                            <th>Promo Disc.</th>
                            <th>Total Pay</th>
                            <th>Driver<br><input type="text" class="filter-input" onkeyup="filterTable(10, this)" placeholder="Driver.."></th>
                            <th>Feedback<br><input type="text" class="filter-input" onkeyup="filterTable(11, this)" placeholder="Feedback.."></th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody id="h-tbody"></tbody>
                </table>
            </div>
        </div>

        <!-- Menu Section -->
        <div id="menu" class="section">
            <div class="section-header" style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px;">
                <div style="display:flex; align-items:center; gap:15px;">
                    <h2 style="margin:0;">Menu Management</h2>
                    <div style="background: #fff; padding: 5px 15px; border-radius: 10px; border: 1px solid #eee; display: flex; align-items: center; gap: 8px;">
                        <span style="font-size: 10px; font-weight: 700; color: #666; text-transform: uppercase;">Global Menu</span>
                        <label class="switch"><input type="checkbox" id="global-menu-switch" onchange="toggleAllMenu(this.checked)"><span class="slider"></span></label>
                    </div>
                </div>
                <button class="btn-gold" style="width:auto; padding:10px 20px;" onclick="createCategory()">+ New Category</button>
            </div>
            <div class="card" id="menu-form-card">
                <h3 id="form-title">Add New Item</h3>
                <div class="menu-form-grid" style="display:grid; grid-template-columns: 1fr 150px 1fr; gap:10px; margin-top:10px;">
                    <input type="text" id="m-name" placeholder="Item Name">
                    <input type="number" id="m-price" placeholder="Price">
                    <select id="m-cat-select"><option value="" disabled selected>Select Category</option></select>
                </div>
                <div style="margin-top:15px;">
                    <label style="font-size: 11px; font-weight: 700; color: var(--primary);">ITEM PHOTO</label>
                    <input type="file" id="m-img-file" accept="image/*" style="margin-top:5px; padding: 8px; border: 1px dashed var(--primary);">
                    <small id="edit-img-note" style="display:none; color:#888;">(Leave blank to keep existing image)</small>
                </div>
                <div style="display:flex; gap:10px; margin-top:15px;">
                    <button id="add-item-btn" class="btn-gold" onclick="addItem()">Save Item to Menu</button>
                    <button id="cancel-edit-btn" class="btn-gold" style="background:#666; display:none;" onclick="resetMenuForm()">Cancel</button>
                </div>
            </div>
            <div id="menu-view"></div>
        </div>

        <!-- Drivers -->
        <div id="drivers" class="section">
            <h2 style="font-weight:700;">Driver Management</h2>
            <div class="card" style="overflow-x:auto;">
                <h3 style="margin-bottom:10px; font-size:14px; color:var(--primary);">Pending Approvals</h3>
                <table style="min-width:1500px;">
                    <thead><tr><th>Full Name</th><th>Contact Info</th><th>Identity & License</th><th>Profile Details</th><th>Credentials</th><th>Action</th></tr></thead>
                    <tbody id="d-pending"></tbody>
                </table>
                <h3 style="margin-top:40px; margin-bottom:10px; font-size:14px; color:var(--success);">Active Partner Fleet</h3>
                <table style="min-width:1500px;">
                    <thead><tr><th>Full Name</th><th>Contact Info</th><th>Identity & License</th><th>Profile Details</th><th>Credentials</th><th>Action</th></tr></thead>
                    <tbody id="d-approved"></tbody>
                </table>
            </div>
        </div>

        <!-- Advertisements Tab -->
        <div id="ads" class="section">
            <div class="section-header" style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px;">
                <h2 style="font-weight:700;">Promocode Management</h2>
                <button class="btn-gold" style="width:auto; padding:10px 20px; background:#2ecc71;" onclick="openPromoModal()">+ New Promocode</button>
            </div>

            <div class="card">
                <h3 style="font-size:14px; margin-bottom:15px; color:var(--primary);">Active Promocodes</h3>
                <div id="active-promo-container" style="display:flex; flex-direction:column; gap:15px;"></div>
            </div>

            <div class="card" style="margin-top:20px; overflow-x:auto;">
                <h3 style="font-size:14px; margin-bottom:15px;">Promocode History (Stopped)</h3>
                <table style="min-width:800px;">
                    <thead><tr><th>Code Name</th><th>Target</th><th>Type</th><th>Value</th><th>Poster</th><th>Action</th></tr></thead>
                    <tbody id="promo-history-list"></tbody>
                </table>
            </div>

            <hr style="margin: 40px 0; border: 1px solid #eee;">

            <div class="section-header" style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px;">
                <h2 style="font-weight:700;">Advertisement Banners</h2>
                <div class="card" style="margin:0; padding:12px 25px; border:2px solid #eee; display:flex; align-items:center; gap:10px;">
                    <span style="font-size: 11px; font-weight: 700; color: #666;">BANNER CAROUSEL</span>
                    <label class="switch"><input type="checkbox" id="banner-toggle" onchange="db.ref('settings/banner_enabled').set(this.checked)"><span class="slider"></span></label>
                </div>
            </div>
            <div class="card">
                <h3 style="font-size:14px; margin-bottom:15px; color:var(--primary);">Upload New Banner (.jpg, .gif)</h3>
                <div class="ads-upload-row" style="display:flex; gap:10px; align-items:flex-end;">
                    <div style="flex:1;"><input type="file" id="ad-file" accept="image/jpeg, image/gif" style="padding:10px; border: 1px dashed var(--primary);"></div>
                    <button id="ad-upload-btn" class="btn-gold" style="width:auto; padding:12px 30px;" onclick="uploadBanner()">Add & Upload Banner</button>
                </div>
            </div>
            <div class="card">
                <h3 style="font-size:14px; margin-bottom:10px;">Current Banners</h3>
                <div id="ad-list" class="ad-grid"></div>
            </div>
        </div>

        <!-- Customers -->
        <div id="customers" class="section">
            <h2 style="font-weight:700;">Customer Base</h2>
            <div class="card" style="padding:0; overflow-x:auto;">
                <table id="customer-table" style="min-width:1200px;">
                    <thead><tr><th>Name / Profile Details</th><th>Status</th><th>Contact Information</th><th>Location</th><th>Metrics</th><th>Last Order</th><th>Action</th></tr></thead>
                    <tbody id="c-tbody"></tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Assign Driver Modal -->
<div id="driver-modal" style="display:none; position:fixed; inset:0; background:rgba(0,0,0,0.7); z-index:3000000; justify-content:center; align-items:center;">
    <div class="card" style="width:350px; text-align:center;">
        <h3>Assign Delivery Partner</h3>
        <div id="modal-driver-list" style="max-height:300px; overflow-y:auto; margin:15px 0;"></div>
        <button class="btn-gold" style="background:#666" onclick="document.getElementById('driver-modal').style.display='none'">Cancel</button>
    </div>
</div>

<!-- Manual Order Modal -->
<div id="manual-order-modal" style="display:none; position:fixed; inset:0; background:rgba(0,0,0,0.7); z-index:3000000; justify-content:center; align-items:center; padding:20px;">
    <div class="card" style="width:100%; max-width:550px; text-align:left; max-height:95vh; overflow-y:auto; border-radius:20px; padding:25px;">
        <h3 style="margin-bottom:15px; color:var(--primary); font-size:20px; border-bottom:1px solid #eee; padding-bottom:10px;"><i class="fas fa-plus-circle"></i> Place Manual Order</h3>
        <div style="display:flex; gap:10px; margin-bottom:10px;">
            <div class="input-group" style="flex:1; margin-bottom:0;"><label>Customer Name</label><input type="text" id="mo-name" placeholder="Name"></div>
            <div class="input-group" style="flex:1; margin-bottom:0;"><label>Mobile Number</label><input type="text" id="mo-phone" placeholder="10 Digits"></div>
        </div>
        <div class="input-group" style="margin-bottom:10px; position:relative;">
            <label>Delivery Address</label>
            <input type="text" id="mo-address" placeholder="Search address within 25km...">
        </div>
        <div id="mo-map" style="width:100%; height:160px; border-radius:12px; background:#e0e0e0; margin-bottom:15px;"></div>
        <div class="input-group" style="margin-bottom:15px;">
            <label>Manual Delivery Charge (₹)</label>
            <input type="number" id="mo-delivery" placeholder="Enter custom delivery fee" value="0" oninput="renderManualCart()">
            <small id="mo-distance-text" style="color:#888; font-size:11px; font-weight:600; display:block; margin-top:4px;">Road Distance: Calculating...</small>
        </div>
        <div style="background:#f9f9f9; padding:15px; border-radius:12px; border:1px solid #eee; margin-bottom:15px;">
            <label style="font-size:11px; font-weight:700; color:var(--primary); display:block; margin-bottom:8px;">ADD MENU ITEMS</label>
            <div style="display:flex; gap:10px; margin-bottom:10px;">
                <select id="mo-item-select" style="flex:1;"></select>
                <input type="number" id="mo-item-qty" value="1" min="1" style="width:70px; text-align:center;">
                <button class="btn-gold" style="width:auto; padding:10px 15px;" onclick="addManualItem()"><i class="fas fa-plus"></i></button>
            </div>
            <div id="mo-cart-list" style="margin-top:10px; max-height:100px; overflow-y:auto; border-top:1px dashed #ddd; padding-top:10px;">
                <p style="color:#aaa; font-size:12px; text-align:center;">Cart is empty</p>
            </div>
            <div style="text-align:right; margin-top:10px; font-weight:700; font-size:14px; color:var(--success);">
                Order Total: ₹<span id="mo-total-display">0</span>
            </div>
        </div>
        <div style="display:flex; gap:10px;">
            <button id="mo-submit-btn" class="btn-gold" onclick="submitManualOrder()">Place Order</button>
            <button class="btn-gold" style="background:#ccc; color:#333;" onclick="closeManualOrderModal()">Cancel</button>
        </div>
    </div>
</div>

<!-- Promo Code Creation Modal -->
<div id="promo-modal" style="display:none; position:fixed; inset:0; background:rgba(0,0,0,0.7); z-index:3000000; justify-content:center; align-items:center;">
    <div class="card" style="width:400px; text-align:left; max-height:90vh; overflow-y:auto;">
        <h3 style="text-align:center; margin-bottom:15px;">Launch Promocode</h3>
        <div class="input-group">
            <label>Promo Code Name (Unique)</label>
            <input type="text" id="p-code" placeholder="e.g. WELCOME50" oninput="this.value = this.value.toUpperCase()">
        </div>
        <div class="input-group">
            <label>Applicable To</label>
            <select id="p-target">
                <option value="all">All Customers</option>
                <option value="new_user">First Time Customers Only</option>
            </select>
        </div>
        <div class="input-group">
            <label>Discount Type</label>
            <select id="p-type">
                <option value="flat">Flat Amount (₹)</option>
                <option value="percent">Percentage (%)</option>
            </select>
        </div>
        <div class="input-group">
            <label>Discount Value</label>
            <input type="number" id="p-amount" placeholder="e.g. 50">
        </div>
        <div class="input-group">
            <label>Promo Poster (3:4 ratio) - Required</label>
            <input type="file" id="p-poster" accept="image/jpeg, image/png, image/webp" style="padding:10px; border: 1px dashed var(--primary);">
        </div>
        <div style="display:flex; gap:10px; margin-top:20px;">
            <button id="btn-save-promo" class="btn-gold" onclick="savePromo()">Save & Launch</button>
            <button class="btn-gold" style="background:#ccc; color:#333;" onclick="document.getElementById('promo-modal').style.display='none'">Cancel</button>
        </div>
    </div>
</div>

<!-- Firebase and external scripts -->
<script src="https://www.gstatic.com/firebasejs/9.17.1/firebase-app-compat.js"></script>
<script src="https://www.gstatic.com/firebasejs/9.17.1/firebase-auth-compat.js"></script>
<script src="https://www.gstatic.com/firebasejs/9.17.1/firebase-database-compat.js"></script>

<!-- Local scripts with cache‑busting -->
<script src="assets/js/firebase-init.js?v=<?= filemtime('assets/js/firebase-init.js') ?>"></script>
<script src="assets/js/admin.js?v=<?= filemtime('assets/js/admin.js') ?>"></script>

</body>
</html>