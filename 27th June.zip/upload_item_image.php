<?php
// upload_item_image.php
header('Content-Type: application/json');

$allowed = ['jpg', 'jpeg', 'png', 'gif', 'webp'];

// Determine target directory based on type
$type = isset($_POST['type']) ? $_POST['type'] : 'item';
if ($type === 'banner') {
    $targetDir = __DIR__ . '/assets/images/banners/';
    $prefix = 'banner_';
} else {
    $targetDir = __DIR__ . '/itemimages/';
    $prefix = 'item_';
}

if (!is_dir($targetDir)) {
    mkdir($targetDir, 0755, true);
}

// --- Handle deletion ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'delete') {
    $filename = $_POST['filename'] ?? '';
    if (!$filename) {
        echo json_encode(['success' => false, 'error' => 'No filename provided']);
        exit;
    }
    // Security: only allow filenames that start with the expected prefix
    if (!preg_match('/^(' . $prefix . '|item_)/', $filename)) {
        echo json_encode(['success' => false, 'error' => 'Invalid filename']);
        exit;
    }
    $path = $targetDir . $filename;
    if (file_exists($path)) {
        if (unlink($path)) {
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false, 'error' => 'Failed to delete file']);
        }
    } else {
        echo json_encode(['success' => false, 'error' => 'File not found']);
    }
    exit;
}

// --- Handle upload ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['image'])) {
    $file = $_FILES['image'];
    if ($file['error'] !== UPLOAD_ERR_OK) {
        echo json_encode(['success' => false, 'error' => 'Upload error: ' . $file['error']]);
        exit;
    }
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, $allowed)) {
        echo json_encode(['success' => false, 'error' => 'Invalid file type']);
        exit;
    }
    $filename = $prefix . time() . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
    $dest = $targetDir . $filename;
    if (move_uploaded_file($file['tmp_name'], $dest)) {
        // Return the relative URL to be stored in Firebase
        if ($type === 'banner') {
            $url = 'assets/images/banners/' . $filename;
        } else {
            $url = $filename; // just the filename, to be prefixed with 'itemimages/' on display
        }
        echo json_encode(['success' => true, 'filename' => $filename, 'url' => $url]);
    } else {
        echo json_encode(['success' => false, 'error' => 'Failed to move uploaded file']);
    }
} else {
    echo json_encode(['success' => false, 'error' => 'No file or invalid request']);
}
?>