<?php require_once 'includes/config.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Cha A Chumuk | Rider Partner</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
    <!-- Cache‑busting for CSS -->
    <link rel="stylesheet" href="assets/css/driver.css?v=<?= filemtime('assets/css/driver.css') ?>">
</head>
<body>

    <audio id="ringer" src="assets/audio/ringer.mp3" loop preload="auto"></audio>

    <!-- LOADING SCREEN -->
    <div id="loader-wrapper">
        <div class="loader-icon-box">
            <img src="assets/images/logo.png" class="loader-logo">
            <i class="fas fa-motorcycle loader-bike"></i>
        </div>
        <div class="loader-text">Cha A Chumuk Rider</div>
        <div class="progress-area">
            <i class="fas fa-motorcycle riding-bike"></i>
            <div class="progress-fill"></div>
        </div>
    </div>

    <!-- LOGIN SCREEN -->
    <div id="screen-login" class="screen auth-container">
        <div class="auth-card">
            <center><img src="assets/images/logo.png" style="width: 80px; margin-bottom: 15px;"></center>
            <h2 style="text-align:center; margin-bottom:20px;">Partner Login</h2>
            <div class="form-group"><label>Email Address</label><input type="email" id="login-email" placeholder="email@example.com"></div>
            <div class="form-group"><label>Password</label><input type="password" id="login-pass" placeholder="••••••••"></div>
            <div id="login-error" class="error-txt">Invalid email or password</div>
            <button class="btn btn-primary" onclick="handleLogin()">Login to Dashboard</button>
            <p style="text-align:center; margin-top:20px; font-size:12px; color:#666;">Not a partner? <a href="javascript:void(0)" onclick="window.switchScreen('screen-register')" style="color:var(--primary); font-weight:600; text-decoration:none;">Register Now</a></p>
        </div>
    </div>

    <!-- REGISTER SCREEN -->
    <div id="screen-register" class="screen auth-container" style="overflow-y: auto; padding-top: 50px; padding-bottom: 50px;">
        <div class="auth-card">
            <h2>Registration</h2>
            <div class="form-group"><label>Full Name</label><input type="text" id="r-name"></div>
            <div class="form-group"><label>Mobile Number</label><input type="tel" id="r-phone"></div>
            <div class="form-group"><label>Email Address</label><input type="email" id="r-email"></div>
            <div class="form-group"><label>Full Address</label><input type="text" id="r-addr"></div>
            <div style="display:flex; gap:10px;"><div class="form-group" style="flex:1"><label>DOB</label><input type="date" id="r-dob"></div><div class="form-group" style="flex:1"><label>Blood Group</label><select id="r-blood"><option value="">Select</option><option>A+</option><option>A-</option><option>B+</option><option>B-</option><option>O+</option><option>O-</option><option>AB+</option><option>AB-</option></select></div></div>
            <div class="form-group"><label>Highest Education</label><input type="text" id="r-edu"></div>
            <div class="form-group"><label>Driving License</label><input type="text" id="r-license"></div>
            <div class="form-group"><label>Aadhar Number</label><input type="number" id="r-adhar"></div>
            <div class="form-group"><label>Set Password</label><input type="password" id="r-pass"></div>
            <div style="display:flex; gap:10px; margin:15px 0;"><input type="checkbox" id="r-agree" style="width:20px;"><label style="font-size:10px; color:#666; text-transform:none;">I agree to submit details for verification</label></div>
            <button class="btn btn-primary" onclick="handleRegister()">Submit for Approval</button>
            <button class="btn btn-outline" onclick="window.switchScreen('screen-login')" style="border:none;">Back to Login</button>
        </div>
    </div>

    <!-- PENDING SCREEN -->
    <div id="screen-pending" class="screen auth-container">
        <div class="auth-card" style="text-align:center;">
            <i class="fas fa-clock fa-4x" style="color:var(--primary); margin-bottom:20px;"></i>
            <h2>Approval Pending</h2>
            <p style="font-size:13px; color:#666; margin:15px 0; line-height:1.6;">Your account is under review by the administrator. Please logout and check back later.</p>
            <button class="btn btn-outline" onclick="auth.signOut()">Logout</button>
        </div>
    </div>

    <!-- MAIN APP SCREEN -->
    <div id="screen-app" class="screen">
        <div id="app-header">
            CHA A CHUMUK PARTNER
            <i class="fas fa-sync-alt" id="refresh-trigger" onclick="refreshLiveOrders()"></i>
        </div>
        <div class="content-area">
            <div id="tab-live" class="tab-content active"><div id="live-container"></div></div>
            <div id="tab-history" class="tab-content">
                <div class="filter-bar">
                    <div style="display:flex; gap:10px; align-items:center;"><input type="date" id="history-date-filter" onchange="renderOrders()" style="flex:1; padding:10px; border:1.5px solid #eee; border-radius:10px; outline:none; font-size:13px;"><button onclick="clearFilter()" style="background:#eee; border:none; padding:10px 15px; border-radius:10px; font-size:12px; font-weight:600; cursor:pointer;">Clear</button></div>
                    <div class="stats-box"><span>Earnings (Delivery Fees)</span><span id="total-delivery-earnings">₹0</span></div>
                </div>
                <div id="history-container"></div>
            </div>
            <div id="tab-profile" class="tab-content">
                <div class="card">
                    <div style="text-align:center; margin-bottom:20px;"><div style="width:70px; height:70px; background:#eee; border-radius:50%; display:inline-flex; align-items:center; justify-content:center; font-size:30px; color:#bbb;"><i class="fas fa-user"></i></div><p style="font-size:10px; color:var(--danger); margin-top:10px;"><i class="fas fa-lock"></i> Account details locked by Admin</p></div>
                    <div class="profile-row"><label>Full Name</label><span id="p-name"></span></div>
                    <div class="profile-row"><label>Mobile</label><span id="p-phone"></span></div>
                    <div class="profile-row"><label>Email</label><span id="p-email"></span></div>
                    <div class="profile-row"><label>Aadhar</label><span id="p-adhar"></span></div>
                    <div class="profile-row"><label>License</label><span id="p-license"></span></div>
                    <div class="profile-row"><label>Blood Group</label><span id="p-blood"></span></div>
                    <button class="btn btn-outline" style="margin-top:30px;" onclick="auth.signOut()">Logout Partner</button>
                </div>
            </div>
        </div>
        <nav class="bottom-nav">
            <div class="nav-item active" onclick="switchTab('tab-live', this)"><i class="fas fa-route"></i>Live</div>
            <div class="nav-item" onclick="switchTab('tab-history', this)"><i class="fas fa-history"></i>History</div>
            <div class="nav-item" onclick="switchTab('tab-profile', this)"><i class="fas fa-id-card"></i>Profile</div>
        </nav>
    </div>

    <!-- Firebase and external scripts with cache‑busting -->
    <script src="https://www.gstatic.com/firebasejs/9.17.1/firebase-app-compat.js"></script>
    <script src="https://www.gstatic.com/firebasejs/9.17.1/firebase-auth-compat.js"></script>
    <script src="https://www.gstatic.com/firebasejs/9.17.1/firebase-database-compat.js"></script>

    <script src="assets/js/firebase-init.js?v=<?= filemtime('assets/js/firebase-init.js') ?>"></script>
    <script src="assets/js/driver.js?v=<?= filemtime('assets/js/driver.js') ?>"></script>
</body>
</html>