// assets/js/admin.js
// Admin panel logic (orders, menu, analytics, drivers, ads, promos)

// ===== USE auth AND db FROM firebase-init.js =====
// Do NOT redeclare auth and db here - they are already declared in firebase-init.js
// ===== END =====

// Global variables
let salesChart = null, ringerActive = false, currentAssignId = null;
let globalOrdersList = [];
let globalUsersList = [];
let editingItemId = null;
let existingImageUrl = "";
let systemMenuCache = [];
let manualMap = null, manualMarker = null, manualAutocomplete = null, manualDistService = null;
let manualCart = [];
let manualCurrentDistance = 0;
const REST_COORDS = { lat: 22.7285, lng: 87.86883 };
let lastOrdersSnapshot = null; // store the last snapshot for manual refresh

// --- Helper to delete an image from server ---
async function deleteImageFile(filename, type = 'item') {
    if (!filename) return;
    try {
        const formData = new FormData();
        formData.append('action', 'delete');
        formData.append('filename', filename);
        if (type === 'banner') {
            formData.append('type', 'banner');
        }
        const res = await fetch('upload_item_image.php', { method: 'POST', body: formData });
        const data = await res.json();
        if (!data.success) console.warn("Failed to delete old image:", data.error);
    } catch (e) { console.warn("Error deleting image:", e); }
}

// --- Functions ---

function stopRinger() { 
    const ringer = document.getElementById('orderRinger');
    if(ringer) { ringer.pause(); ringer.currentTime = 0; }
    ringerActive = false; 
}

function updSt(id, s) { stopRinger(); db.ref('orders/' + id).update({ status: s }); }

function handleStFlow(id, v) { 
    stopRinger(); 
    if(v === 'ASSIGN') { currentAssignId = id; openDriverList(); } 
    else if(v === 'CANCEL') { cancelOrder(id); } 
    else { updSt(id, v); } 
}

function cancelOrder(id) { if(confirm("Cancel this order? It will be permanently deleted.")) { db.ref('orders/' + id).remove(); } }

function startMasterSync() {
    db.ref('settings/is_open').on('value', s => { if(document.getElementById('master-switch')) document.getElementById('master-switch').checked = s.val() });
    db.ref('orders').on('value', s => { 
        lastOrdersSnapshot = s;
        globalOrdersList = [];
        s.forEach(c => { globalOrdersList.push({...c.val(), _id: c.key}); });
        renderKitchenHub(s); 
        renderSalesHistory(s); 
        processAnalytics(s); 
        renderCustomers();
    });
    db.ref('settings/menu_active').on('value', s => { if(document.getElementById('global-menu-switch')) document.getElementById('global-menu-switch').checked = (s.val() !== false); });
    db.ref('settings/banner_enabled').on('value', s => { if(document.getElementById('banner-toggle')) document.getElementById('banner-toggle').checked = (s.val() !== false); });
    db.ref('banners').on('value', snap => {
        const list = document.getElementById('ad-list'); list.innerHTML = "";
        snap.forEach(b => {
            list.innerHTML += `<div class="ad-item"><img src="${b.val().url}"><button class="ad-del-btn" onclick="db.ref('banners/${b.key}').remove()"><i class="fas fa-trash"></i></button></div>`;
        });
    });
    db.ref('promocode').on('value', snap => { processPromos(snap); });
    db.ref('settings/categories').on('value', catSnap => {
        const sel = document.getElementById('m-cat-select'), view = document.getElementById('menu-view');
        if(!sel || !view) return;
        sel.innerHTML = '<option value="" disabled selected>Select Category</option>'; view.innerHTML = "";
        const cats =[];
        catSnap.forEach(c => {
            cats.push(c.key); sel.innerHTML += `<option value="${c.key}">${c.key}</option>`;
            view.innerHTML += `<div class="cat-box"><div class="cat-header"><h3>${c.key}</h3><div><label class="switch"><input type="checkbox" onchange="db.ref('settings/categories/${c.key}').set(this.checked)" ${c.val() ? 'checked' : ''}><span class="slider"></span></label><i class="fas fa-trash-alt" style="margin-left:15px; color:var(--danger); cursor:pointer;" onclick="db.ref('settings/categories/${c.key}').remove()"></i></div></div><table><tbody id="body-${c.key.replace(/\s/g, '')}"></tbody></table></div>`;
        });
        db.ref('menu').on('value', itemSnap => {
            cats.forEach(cat => { const b = document.getElementById('body-' + cat.replace(/\s/g, '')); if(b) b.innerHTML = ""; });
            systemMenuCache =[];
            itemSnap.forEach(item => {
                const v = item.val(); 
                v.key = item.key;
                systemMenuCache.push(v);
                const b = document.getElementById('body-' + (v.category || 'General').replace(/\s/g, ''));
                if(b) {
                    let imgUrl = v.image || "";
                    if(imgUrl && !imgUrl.startsWith('http')) imgUrl = `itemimages/${imgUrl}`;
                    if(!imgUrl) imgUrl = 'https://via.placeholder.com/100?text=Food';
                    b.innerHTML += `<tr><td width="50"><img src="${imgUrl}" width="35" height="35" style="border-radius:5px; object-fit:cover;"></td><td><b>${v.name}</b><br>₹${v.price}</td><td><label class="switch"><input type="checkbox" onchange="db.ref('menu/${item.key}/status').set(this.checked)" ${v.status ? 'checked' : ''}><span class="slider"></span></label></td><td><i class="fas fa-edit" style="color:var(--blue); cursor:pointer; margin-right:15px;" onclick='initEdit("${item.key}", ${JSON.stringify(v).replace(/'/g, "\\'")})'></i><i class="fas fa-trash" style="color:var(--danger); cursor:pointer;" onclick="if(confirm('Delete item?')) db.ref('menu/${item.key}').remove()"></i></td></tr>`;
                }
            });
            populateManualOrderSelect();
        });
    });
    db.ref('drivers').on('value', snap => {
        const p = document.getElementById('d-pending'), a = document.getElementById('d-approved');
        p.innerHTML = ""; a.innerHTML = "";
        snap.forEach(c => {
            const d = c.val();
            if(!d) return;
            const row = `<tr><td><b>${d.name || 'No Name'}</b></td><td>Phone: <b>${d.phone || '-'}</b><br>Email: <small>${d.email || 'N/A'}</small><br><a href="tel:${d.phone}" class="btn-gold" style="width:auto; padding:5px 10px; font-size:10px; background:var(--blue); margin-top:5px; text-decoration:none;"><i class="fas fa-phone"></i> CALL NOW</a></td><td>DL: <b>${d.license||'-'}</b><br>Aadhar: <b>${d.adhar||'-'}</b></td><td>DOB: ${d.dob||'-'}<br>Blood: ${d.blood||'-'}</td><td><code>${d.pass||'-'}</code></td><td>${d.status === 'approved' ? `<button class="btn-gold" style="background:var(--danger); padding:6px 12px; width:auto; font-size:11px;" onclick="db.ref('drivers/${c.key}').remove()">Unregister</button>` : `<div style="display:flex; gap:5px;"><button class="btn-gold" style="background:var(--success); padding:6px 12px; width:auto; font-size:11px;" onclick="db.ref('drivers/${c.key}/status').set('approved')">Approve</button><button class="btn-gold" style="background:var(--danger); padding:6px 12px; width:auto; font-size:11px;" onclick="db.ref('drivers/${c.key}').remove()">Deny</button></div>`}</td></tr>`;
            if(d.status === 'approved') a.innerHTML += row; else p.innerHTML += row;
        });
    });
    db.ref('users').on('value', snap => {
        globalUsersList = [];
        snap.forEach(c => { 
            const u = c.val();
            if(u) globalUsersList.push({...u, _key: c.key}); 
        });
        renderCustomers();
    });
    db.ref('settings/auto_schedule').on('value', s => { document.getElementById('auto-schedule-switch').checked = (s.val() === true); });
    db.ref('settings/open_time').on('value', s => { document.getElementById('open-time').value = s.val() || ''; });
    db.ref('settings/close_time').on('value', s => { document.getElementById('close-time').value = s.val() || ''; });
    setInterval(autoScheduleCheck, 60000); autoScheduleCheck();
}

function renderCustomers() {
    const b = document.getElementById('c-tbody'); 
    if(!b) return;
    b.innerHTML = "";
    globalUsersList.forEach(u => {
        let oCount = 0;
        let tSpent = 0;
        let lOrderDate = 0;
        let rawPhone = u.phone ? u.phone.toString().replace(/\D/g, '') : '';
        if (rawPhone.length > 10) rawPhone = rawPhone.slice(-10);
        if (rawPhone) {
            const userOrders = globalOrdersList.filter(o => {
                let op = o.customerPhone ? o.customerPhone.toString().replace(/\D/g, '') : '';
                if(op.length > 10) op = op.slice(-10);
                return op === rawPhone && (o.status || '').toLowerCase() === 'delivered';
            });
            oCount = userOrders.length;
            userOrders.forEach(o => {
                tSpent += parseFloat(o.total || 0);
                if (o.timestamp > lOrderDate) lOrderDate = o.timestamp;
            });
        }
        if (oCount === 0) oCount = u.orderCount || 0;
        if (tSpent === 0) tSpent = u.totalSpent || 0;
        let lastOrderStr = lOrderDate ? new Date(lOrderDate).toLocaleString() : (u.lastOrderDate ? new Date(u.lastOrderDate).toLocaleString() : '-');
        let waPhone = rawPhone ? rawPhone : (u.phone || '');
        let actionHtml = `<div style="display:flex; flex-direction:column; gap:5px; margin-bottom:5px;">
            <a href="tel:${u.phone}" class="btn-gold" style="width:100%; padding:6px 10px; font-size:10px; background:var(--blue); text-decoration:none;"><i class="fas fa-phone"></i> CALL</a>
            <a href="https://wa.me/91${waPhone}" target="_blank" class="btn-gold" style="width:100%; padding:6px 10px; font-size:10px; background:var(--wa); text-decoration:none;"><i class="fab fa-whatsapp"></i> WHATSAPP</a>
        </div>
        <i class="fas fa-trash" style="color:var(--danger); cursor:pointer; font-size:14px; display:block; text-align:center;" onclick="if(confirm('Delete customer?')) db.ref('users/${u._key}').remove()"></i>`;
        let emailStr = u.email || 'No Email';
        let imgHtml = u.photoURL || u.profile_picture ? `<img src="${u.photoURL || u.profile_picture}" style="width:35px; height:35px; border-radius:50%; object-fit:cover; border: 1px solid #ccc;">` : `<i class="fas fa-user-circle" style="font-size:30px; color:#ccc;"></i>`;
        let nameHtml = `<div style="display:flex; align-items:center; gap:10px;">
            ${imgHtml}
            <div style="line-height:1.2;">
                <b style="font-size:12px;">${u.name || u.displayName || 'User'}</b><br>
                <span style="font-size:9px; color:#888;">UID: ${u.uid || u._key}</span>
            </div>
        </div>`;
        let contactHtml = `<div style="font-size:11px; line-height:1.5;">
            <span style="color:var(--primary); font-weight:600;"><i class="fas fa-phone"></i> ${u.phone || u.phoneNumber || 'N/A'}</span><br>
            <span style="color:#555;"><i class="fas fa-envelope"></i> ${emailStr}</span>
        </div>`;
        b.innerHTML += `<tr>
            <td>${nameHtml}</td>
            <td>${u.is_verified ? '<span style="color:green; font-size:11px; font-weight:bold;">VERIFIED</span>' : '<span style="color:red; font-size:11px; font-weight:bold;">UNVERIFIED</span>'}</td>
            <td>${contactHtml}</td>
            <td><div style="width:150px; font-size:10px; white-space:normal;">${u.address || '-'}</div></td>
            <td>Orders: <b style="color:var(--primary)">${oCount}</b><br>Spent: <b style="color:var(--success)">₹${tSpent}</b></td>
            <td><span style="font-size:11px;">${lastOrderStr}</span></td>
            <td>${actionHtml}</td>
        </tr>`;
    });
}

function processPromos(snap) {
    const liveContainer = document.getElementById('active-promo-container');
    const historyList = document.getElementById('promo-history-list');
    liveContainer.innerHTML = ""; historyList.innerHTML = "";
    const liveSnap = snap.child('live');
    let liveFound = false;
    if (liveSnap.exists() && typeof liveSnap.val() === 'object' && liveSnap.val().code) {
        db.ref('promocode/live').remove();
        return;
    }
    liveSnap.forEach(child => {
        const live = child.val();
        if(!live || typeof live !== 'object') return;
        const code = child.key;
        liveFound = true;
        let pType = live.type || 'flat';
        let posterHtml = live.poster_url ? `<img src="${live.poster_url}" style="width:60px; height:80px; object-fit:cover; border-radius:8px; border:1px solid #ccc;">` : `<div style="width:60px; height:80px; background:#eee; border-radius:8px; display:flex; align-items:center; justify-content:center; font-size:10px; color:#aaa; text-align:center;">No<br>Poster</div>`;
        let displayTarget = live.userType === 'new_user' ? 'First Time Customers' : 'All Customers';
        let displayVal = pType === 'percent' ? `${live.amount}%` : `₹${live.amount}`;
        liveContainer.innerHTML += `<div style="display:flex; align-items:center; gap:15px; background:#f4f7f6; padding:15px; border-radius:15px; border:1px solid #2ecc71;">${posterHtml}<div style="flex:1;"><h4 style="color:var(--primary); font-size:18px; margin-bottom:5px;">${code}</h4><p style="font-size:12px; color:#555; margin-bottom:3px;"><b>Applies To:</b> ${displayTarget} | <b>Type:</b> ${pType.toUpperCase()}</p><p style="font-size:12px; color:var(--success); font-weight:700;"><b>Value:</b> ${displayVal}</p></div><button class="btn-gold" style="background:var(--danger); width:auto; padding:10px 15px;" onclick="stopPromo('${code}')"><i class="fas fa-ban"></i> Stop</button></div>`;
    });
    if (!liveFound) liveContainer.innerHTML = `<p style="color:#999; font-size:12px; font-style:italic;">No active promocodes running.</p>`;
    const historySnap = snap.child('history');
    historySnap.forEach(child => {
        const h = child.val();
        if(!h || typeof h !== 'object') return;
        const code = h.code || child.key;
        let pType = h.type || 'flat';
        let displayTarget = h.userType === 'new_user' ? 'First Time' : 'All';
        let displayVal = pType === 'percent' ? `${h.amount}%` : `₹${h.amount}`;
        let pImg = h.poster_url ? `<a href="${h.poster_url}" target="_blank" style="color:var(--blue);"><i class="fas fa-image"></i> View</a>` : `-`;
        historyList.innerHTML = `<tr style="color:#888; background:#fdfdfd;"><td><b style="color:#555;">${code}</b></td><td>${displayTarget}</td><td>${pType.toUpperCase()}</td><td>${displayVal}</td><td>${pImg}</td><td><i class="fas fa-trash" style="color:var(--danger); cursor:pointer;" onclick="if(confirm('Delete promo history?')) db.ref('promocode/history/${child.key}').remove()"></i></td></tr>` + historyList.innerHTML;
    });
}

function openPromoModal() {
    document.getElementById('p-code').value = ""; document.getElementById('p-amount').value = ""; document.getElementById('p-poster').value = "";
    document.getElementById('promo-modal').style.display = 'flex';
}

async function savePromo() {
    const code = document.getElementById('p-code').value.trim().toUpperCase();
    const userType = document.getElementById('p-target').value;
    const type = document.getElementById('p-type').value;
    const amount = parseFloat(document.getElementById('p-amount').value);
    const fileInput = document.getElementById('p-poster');
    if(!code || !amount || fileInput.files.length === 0) return alert("Fill all fields!");
    const btn = document.getElementById('btn-save-promo');
    btn.disabled = true; btn.innerText = "Processing...";
    try {
        const s = await db.ref('promocode/live/' + code).once('value');
        if(s.exists()) throw new Error("A live promocode with this name already exists!");
        const h = await db.ref('promocode/history/' + code).once('value');
        if(h.exists()) throw new Error("This name exists in history. Delete history first.");
        // *** LOCAL UPLOAD FOR PROMO POSTERS ***
        const file = fileInput.files[0];
        const formData = new FormData();
        formData.append('image', file);
        formData.append('type', 'banner'); // reuse banner folder for promo posters
        const uploadRes = await fetch('upload_item_image.php', { method: 'POST', body: formData });
        const uploadData = await uploadRes.json();
        if (!uploadData.success) throw new Error(uploadData.error);
        const posterUrl = uploadData.url; // e.g., "assets/images/banners/banner_xxx.jpg"
        await db.ref('promocode/live/' + code).set({ type, userType, amount, poster_url: posterUrl, createdAt: Date.now() });
        alert("Promocode launched!"); document.getElementById('promo-modal').style.display = 'none';
    } catch(e) { alert("Error: " + e.message); } finally { btn.disabled = false; btn.innerText = "Save & Launch"; }
}

function stopPromo(code) {
    if(confirm(`Stop ${code}?`)) {
        db.ref('promocode/live/' + code).once('value', s => {
            if(s.exists()) {
                db.ref('promocode/history/' + code).set(s.val()).then(() => db.ref('promocode/live/' + code).remove());
            }
        });
    }
}

function openManualOrderModal() {
    document.getElementById('mo-name').value = ""; document.getElementById('mo-phone').value = "";
    document.getElementById('mo-address').value = ""; document.getElementById('mo-delivery').value = "0";
    manualCart =[]; renderManualCart();
    document.getElementById('manual-order-modal').style.display = 'flex';
    initAdminMap();
}

function closeManualOrderModal() { document.getElementById('manual-order-modal').style.display = 'none'; }

function populateManualOrderSelect() {
    const sel = document.getElementById('mo-item-select');
    sel.innerHTML = "";
    systemMenuCache.forEach(i => { if(i.status) sel.innerHTML += `<option value="${i.key}">${i.name} - ₹${i.price}</option>`; });
}

function initAdminMap() {
    if(manualMap) { google.maps.event.trigger(manualMap, "resize"); return; }
    manualMap = new google.maps.Map(document.getElementById('mo-map'), { center: REST_COORDS, zoom: 14, disableDefaultUI: true });
    manualMarker = new google.maps.Marker({ position: REST_COORDS, map: manualMap, draggable: true });
    manualDistService = new google.maps.DistanceMatrixService();
    const circle = new google.maps.Circle({ center: REST_COORDS, radius: 25000 });
    manualAutocomplete = new google.maps.places.Autocomplete(document.getElementById('mo-address'), { bounds: circle.getBounds(), strictBounds: true });
    manualAutocomplete.addListener('place_changed', () => {
        const place = manualAutocomplete.getPlace();
        if(place.geometry) {
            manualMarker.setPosition(place.geometry.location); manualMap.panTo(place.geometry.location);
            calcAdminDistance(place.geometry.location);
        }
    });
    manualMarker.addListener('dragend', () => calcAdminDistance(manualMarker.getPosition()));
}

function calcAdminDistance(destination) {
    manualDistService.getDistanceMatrix({ origins: [REST_COORDS], destinations: [destination], travelMode: 'DRIVING' }, (res, status) => {
        if(status === 'OK') {
            const distText = res.rows[0].elements[0].distance.text;
            document.getElementById('mo-distance-text').innerText = `Road Distance: ${distText}`;
        }
    });
}

function addManualItem() {
    const id = document.getElementById('mo-item-select').value;
    const qty = parseInt(document.getElementById('mo-item-qty').value) || 1;
    const itemObj = systemMenuCache.find(i => i.key === id);
    if(!itemObj) return;
    const existing = manualCart.find(i => i.id === id);
    if(existing) existing.qty += qty; else manualCart.push({ id, name: itemObj.name, price: itemObj.price, qty });
    renderManualCart();
}

function renderManualCart() {
    const list = document.getElementById('mo-cart-list');
    let subtotal = 0; list.innerHTML = "";
    if(manualCart.length === 0) { list.innerHTML = `<p style="color:#aaa; font-size:12px; text-align:center;">Cart is empty</p>`; }
    else {
        manualCart.forEach((i, idx) => {
            subtotal += (i.price * i.qty);
            list.innerHTML += `<div class="manual-cart-item"><span>${i.name} x${i.qty}</span><div style="display:flex; align-items:center; gap:10px;"><b>₹${i.price * i.qty}</b><i class="fas fa-times" style="color:var(--danger); cursor:pointer;" onclick="manualCart.splice(${idx},1); renderManualCart();"></i></div></div>`;
        });
    }
    const delFee = parseFloat(document.getElementById('mo-delivery').value) || 0;
    document.getElementById('mo-total-display').innerText = (subtotal + delFee).toFixed(2);
}

function submitManualOrder() {
    const name = document.getElementById('mo-name').value.trim() || 'Manual Customer';
    const phone = document.getElementById('mo-phone').value.trim();
    const address = document.getElementById('mo-address').value.trim() || 'Manual Order';
    const delFee = parseFloat(document.getElementById('mo-delivery').value) || 0;
    if(manualCart.length === 0) return alert("Add items!");
    const pos = manualMarker.getPosition();
    let subtotal = 0; manualCart.forEach(i => subtotal += (i.price * i.qty));
    const orderData = {
        customerName: name, customerPhone: phone || "0000000000", items: manualCart, total: subtotal + delFee,
        deliveryCharge: delFee, subtotal: subtotal, address: address, lat: pos.lat(), lng: pos.lng(),
        paymentMethod: "Manual Order", paymentId: "MANUAL", status: "Accepted", timestamp: Date.now(), isManual: true
    };
    db.ref('orders/ORD-' + Date.now()).set(orderData).then(() => { alert("Manual Order Placed!"); closeManualOrderModal(); });
}

function autoScheduleCheck() {
    db.ref('settings/auto_schedule').once('value', autoS => {
        if(autoS.val() !== true) return;
        db.ref('settings/open_time').once('value', openS => {
            db.ref('settings/close_time').once('value', closeS => {
                const openTime = openS.val(); const closeTime = closeS.val();
                if(!openTime || !closeTime) return;
                const now = new Date(); const currentMinutes = now.getHours() * 60 + now.getMinutes();
                const [oh, om] = openTime.split(':').map(Number); const [ch, cm] = closeTime.split(':').map(Number);
                const openMinutes = oh * 60 + om; const closeMinutes = ch * 60 + cm;
                db.ref('settings/is_open').set(openMinutes <= closeMinutes ? (currentMinutes >= openMinutes && currentMinutes < closeMinutes) : (currentMinutes >= openMinutes || currentMinutes < closeMinutes));
            });
        });
    });
}

function saveTimings() {
    const open = document.getElementById('open-time').value, close = document.getElementById('close-time').value;
    if(!open || !close) return alert("Set both times.");
    db.ref('settings/open_time').set(open); db.ref('settings/close_time').set(close); alert("Timings saved!");
}

// ===== BANNER UPLOAD (LOCAL) =====
async function uploadBanner() {
    const fileInput = document.getElementById('ad-file');
    if(fileInput.files.length === 0) return alert("Select a file (JPG, GIF, PNG, WEBP)");
    const btn = document.getElementById('ad-upload-btn');
    btn.disabled = true; btn.innerText = "Uploading...";
    try {
        const file = fileInput.files[0];
        const formData = new FormData();
        formData.append('image', file);
        formData.append('type', 'banner');
        const uploadRes = await fetch('upload_item_image.php', { method: 'POST', body: formData });
        const uploadData = await uploadRes.json();
        if (!uploadData.success) throw new Error(uploadData.error);
        // Store the relative URL in Firebase
        await db.ref('banners').push({ url: uploadData.url, timestamp: Date.now() });
        alert("Banner Added!");
        fileInput.value = "";
    } catch(e) {
        alert("Upload failed: " + e.message + ". Please try a different image.");
    } finally {
        btn.disabled = false;
        btn.innerText = "Add & Upload Banner";
    }
}

function renderKitchenHub(snap) {
    const k = document.getElementById('k-cont'); k.innerHTML = "";
    let isNewFound = false, isLiveFound = false;
    const inKitchenStatuses =['accepted', 'preparing (10 min)', 'preparing (20 min)', 'preparing (30 min)', 'preparing (45 min)', 'handed over'];
    snap.forEach(c => {
        const o = c.val(); 
        if(!o) return;
        o.id = c.key;
        const statusStr = (o.status || "").toLowerCase().trim();
        if(statusStr !== 'delivered' && statusStr !== 'declined') {
            isLiveFound = true; if(!inKitchenStatuses.includes(statusStr)) isNewFound = true;
            let itemsHtml = ""; if(o.items) o.items.forEach(i => itemsHtml += `<div style="display:flex; justify-content:space-between; font-size:12px; border-bottom:1px dashed #eee; padding:4px 0;"><span>${i.name} <b>x${i.qty||1}</b></span><span>₹${(i.price*(i.qty||1))}</span></div>`);
            let pClass = 'pay-online', pLabel = 'Online Payment';
            if(o.isManual || o.paymentId === 'MANUAL') { pClass = 'pay-manual'; pLabel = 'Manual Order'; }
            else if(o.paymentId === 'COD') { pClass = 'pay-cod'; pLabel = 'Cash On Delivery'; }
            const promoHtml = o.promoCode ? `<div style="margin-top:5px; color:var(--primary); font-size:11px; font-weight:700;"><i class="fas fa-tag"></i> PROMO APPLIED: ${o.promoCode}</div>` : `<div style="margin-top:5px; color:#ccc; font-size:10px;">No promocode applied</div>`;
            k.innerHTML += `<div class="card" style="border-top:6px solid ${!inKitchenStatuses.includes(statusStr) ? 'var(--primary)' : 'var(--success)'}">
                <div style="display:flex; justify-content:space-between; align-items:center;"><b>#${o.id.slice(-5)}</b><span class="pay-badge ${pClass}">${pLabel}</span></div>
                ${promoHtml}
                <div style="margin:12px 0; padding:10px; background:#f9f9f9; border-radius:10px; border:1px solid #eee;">
                    <div style="display:flex; justify-content:space-between; align-items:center;">
                        <div><p style="margin:0; font-weight:700; font-size:14px;">${o.customerName || 'Guest'}</p><p style="margin:2px 0; font-size:13px; color:#444; font-weight:600;">${o.customerPhone}</p></div>
                        <a href="tel:${o.customerPhone}" onclick="stopRinger()" style="background:var(--blue); color:white; width:35px; height:35px; display:flex; align-items:center; justify-content:center; border-radius:50%; text-decoration:none;"><i class="fas fa-phone"></i></a>
                    </div>
                    <p style="margin:8px 0 0 0; font-size:11px; color:#666; line-height:1.4;"><i class="fas fa-map-marker-alt"></i> ${o.address || 'No Address'}</p>
                </div>
                <div style="margin-bottom:12px;">${itemsHtml}<div style="display:flex; justify-content:space-between; margin-top:5px; font-weight:700; border-top:1px solid #ddd; padding-top:5px; font-size:15px;"><span>Total Pay</span><span style="color:var(--success)">₹${o.total}</span></div></div>
                <button class="btn-gold" style="background:var(--dark); color:white; padding:10px; font-size:12px; margin-bottom:10px;" onclick="window.open('https://www.google.com/maps?q=${o.lat},${o.lng}')"><i class="fas fa-location-arrow"></i> MAP</button>
                ${!inKitchenStatuses.includes(statusStr) ? `<div style="display:grid; grid-template-columns:1fr 1fr; gap:10px;"><button onclick="updSt('${o.id}','Accepted')" style="background:var(--success); color:white; border:none; padding:12px; border-radius:10px; font-weight:700; cursor:pointer;">ACCEPT</button><button onclick="updSt('${o.id}','Declined')" style="background:var(--danger); color:white; border:none; padding:12px; border-radius:10px; font-weight:700; cursor:pointer;">DECLINE</button></div>` : `<div class="custom-dropdown"><div class="dropdown-btn" onclick="this.nextElementSibling.classList.toggle('open')"><span style="color:var(--primary); font-weight:600;">${o.status}</span><i class="fas fa-chevron-down"></i></div><div class="dropdown-menu"><div class="dropdown-item" onclick="handleStFlow('${o.id}','Preparing (10 min)')">Preparing (10 min)</div><div class="dropdown-item" onclick="handleStFlow('${o.id}','Preparing (20 min)')">Preparing (20 min)</div><div class="dropdown-item" onclick="handleStFlow('${o.id}','Preparing (30 min)')">Preparing (30 min)</div><div class="dropdown-item assigned" onclick="handleStFlow('${o.id}','ASSIGN')">Handover</div><div class="dropdown-item" onclick="handleStFlow('${o.id}','Delivered')">Mark Delivered</div><div class="dropdown-item cancel" onclick="handleStFlow('${o.id}','CANCEL')">Cancel</div></div></div>`}
            </div>`;
        }
    });
    if(isNewFound) { 
        const ringer = document.getElementById('orderRinger');
        if(!ringerActive) { ringer.play().then(() => ringerActive = true).catch(e => {}); } 
    } else stopRinger();
}

// ========== FIXED renderSalesHistory ==========
function renderSalesHistory(snap) {
    const h = document.getElementById('h-tbody'); 
    h.innerHTML = "";
    snap.forEach(c => {
        const o = c.val(); 
        if(!o || (o.status || "").toLowerCase().trim() !== 'delivered') return;
        
        let pClass = 'pay-online', pLabel = 'Online';
        if(o.isManual || o.paymentId === 'MANUAL') { pClass = 'pay-manual'; pLabel = 'Manual Order'; }
        else if(o.paymentId === 'COD') { pClass = 'pay-cod'; pLabel = 'COD'; }

        let itemList = ""; 
        if(o.items) o.items.forEach(i => itemList += `${i.name} (${i.qty}), `);
        itemList = itemList.replace(/, $/,"");

        let feedbackHtml = `<span style="background: #ffeaa7; color: #d35400; padding: 3px 6px; border-radius: 4px; font-size: 10px; font-weight: bold;">Missing</span>`;

        let feedbackData = null;
        if (o.survey) {
            if (typeof o.survey === 'string') {
                try { feedbackData = JSON.parse(o.survey); } catch(e) { /* ignore */ }
            } else if (typeof o.survey === 'object') {
                feedbackData = o.survey;
            }
        } else if (o.feedback) {
            if (typeof o.feedback === 'string') {
                try { feedbackData = JSON.parse(o.feedback); } catch(e) { /* ignore */ }
            } else if (typeof o.feedback === 'object') {
                feedbackData = o.feedback;
            }
        } else if (o.rating || o.review) {
            feedbackData = { rating: o.rating || o.stars || 0, feedback: o.review || o.survey || '' };
        }

        if (feedbackData) {
            const stars = feedbackData.rating || feedbackData.stars || 0;
            let text = feedbackData.feedback || feedbackData.text || feedbackData.review || "No text provided";
            if (typeof text === 'object') text = JSON.stringify(text);
            feedbackHtml = `<div style="font-size:11px;"><b>${stars} ⭐</b><br><span style="color:#666; word-break:break-word;">${text}</span></div>`;
        }

        h.innerHTML = `<tr>
            <td>#${c.key.slice(-5)}</td>
            <td>${new Date(o.timestamp).toLocaleString()}</td>
            <td>${o.customerName}</td>
            <td><div style="width:150px; font-size:10px; color:#666;">${itemList}</div></td>
            <td><span class="pay-badge ${pClass}">${pLabel}</span></td>
            <td><small>${(o.address||'').substring(0,30)}</small></td>
            <td>₹${o.subtotal||0}</td>
            <td>₹${o.deliveryCharge||0}</td>
            <td style="color:var(--success);">-₹${o.promoDiscount||0}</td>
            <td><b>₹${o.total}</b></td>
            <td>${o.driverName||'-'}</td>
            <td>${feedbackHtml}</td>
            <td><i class="fas fa-trash" style="color:red; cursor:pointer;" onclick="if(confirm('Delete?')) db.ref('orders/${c.key}').remove()"></i></td>
        </tr>` + h.innerHTML;
    });
}
// ========== END FIX ==========

function filterTable(colIdx, input) {
    const filter = input.value.toUpperCase();
    const table = document.getElementById("history-table");
    const tr = table.getElementsByTagName("tr");
    for (let i = 1; i < tr.length; i++) {
        const td = tr[i].getElementsByTagName("td")[colIdx];
        if (td) {
            const txtValue = td.textContent || td.innerText;
            tr[i].style.display = txtValue.toUpperCase().indexOf(filter) > -1 ? "" : "none";
        }
    }
}

function processAnalytics(snap) {
    const now = new Date(); let d=0, dc=0, w=0, wc=0, m=0, mc=0, y=0, yc=0;
    let chartLabels = [];
    let chartData = [];
    for(let i=6; i>=0; i--) {
        let dDate = new Date(); dDate.setDate(now.getDate() - i);
        chartLabels.push(dDate.toLocaleDateString('en-US', {month:'short', day:'numeric'}));
        chartData.push(0);
    }
    snap.forEach(c => { 
        const o = c.val(); 
        if(o && (o.status || '').toLowerCase() === 'delivered') { 
            const od = new Date(o.timestamp); 
            const amt = parseInt(o.total || 0); 
            y+=amt; yc++; 
            if(od.toDateString() === now.toDateString()){ d+=amt; dc++; } 
            if((now-od)<7*24*60*60*1000){ w+=amt; wc++; } 
            if(od.getMonth()===now.getMonth() && od.getFullYear()===now.getFullYear()){ m+=amt; mc++; } 
            for(let i=0; i<7; i++) {
                let cd = new Date(); cd.setDate(now.getDate() - (6-i));
                if(od.toDateString() === cd.toDateString()) {
                    chartData[i] += amt;
                }
            }
        }
    });
    if(document.getElementById('s-daily')){
        document.getElementById('s-daily').innerText = "₹" + d; document.getElementById('cnt-daily').innerText = dc;
        document.getElementById('s-weekly').innerText = "₹" + w; document.getElementById('cnt-weekly').innerText = wc;
        document.getElementById('s-monthly').innerText = "₹" + m; document.getElementById('cnt-monthly').innerText = mc;
        document.getElementById('s-yearly').innerText = "₹" + y; document.getElementById('cnt-yearly').innerText = yc;
    }
    if(salesChart) {
        salesChart.data.labels = chartLabels;
        salesChart.data.datasets[0].data = chartData;
        salesChart.update();
    } else {
        const ctx = document.getElementById('salesChart');
        if(ctx) {
            salesChart = new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: chartLabels,
                    datasets: [{
                        label: 'Sales (₹) Over Last 7 Days',
                        data: chartData,
                        backgroundColor: 'rgba(255, 159, 28, 0.5)',
                        borderColor: 'rgba(255, 159, 28, 1)',
                        borderWidth: 1,
                        borderRadius: 4
                    }]
                },
                options: { responsive: true, scales: { y: { beginAtZero: true } } }
            });
        }
    }
}

function showTab(id, el) { document.querySelectorAll('.section').forEach(s => s.classList.remove('active')); document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active')); document.getElementById(id).classList.add('active'); el.classList.add('active'); }

function manualRefreshKitchen() { 
    if(lastOrdersSnapshot) {
        renderKitchenHub(lastOrdersSnapshot);
    } else {
        db.ref('orders').once('value', s => renderKitchenHub(s));
    }
}

function openDriverList() { 
    const list = document.getElementById('modal-driver-list'); 
    list.innerHTML = ""; 
    db.ref('drivers').once('value', s => { 
        s.forEach(c => { 
            if(c.val().status === 'approved') list.innerHTML += `<div onclick="assignPartner('${c.key}','${c.val().name}','${c.val().phone}')" style="padding:12px; border-bottom:1px solid #eee; cursor:pointer; font-weight:600;">${c.val().name}</div>`; 
        }); 
    }); 
    document.getElementById('driver-modal').style.display = 'flex'; 
}

function assignPartner(dId, dN, dP) { 
    db.ref('orders/'+currentAssignId).update({status:'Handed Over', driverId:dId, driverName:dN, driverPhone:dP}); 
    document.getElementById('driver-modal').style.display='none'; 
}

function createCategory() { const c = prompt("Category Name:"); if(c) db.ref('settings/categories/' + c).set(true); }

function toggleAllMenu(status) { 
    db.ref('settings/menu_active').set(status); 
    db.ref('menu').once('value', snapshot => { 
        const updates = {}; 
        snapshot.forEach(child => { 
            updates[`menu/${child.key}/status`] = status; 
        }); 
        db.ref().update(updates); 
    }); 
}

function initEdit(id, data) {
    editingItemId = id; existingImageUrl = data.image;
    document.getElementById('m-name').value = data.name; document.getElementById('m-price').value = data.price;
    document.getElementById('m-cat-select').value = data.category; document.getElementById('form-title').innerText = "Edit Item";
    document.getElementById('add-item-btn').innerText = "Update"; document.getElementById('cancel-edit-btn').style.display = "block";
    document.getElementById('edit-img-note').style.display = 'block';
}

function resetMenuForm() {
    editingItemId = null; existingImageUrl = ""; document.getElementById('m-name').value = ""; document.getElementById('m-price').value = "";
    document.getElementById('m-cat-select').value = ""; document.getElementById('m-img-file').value = "";
    document.getElementById('form-title').innerText = "Add New Item"; document.getElementById('add-item-btn').innerText = "Save";
    document.getElementById('cancel-edit-btn').style.display = "none";
    document.getElementById('edit-img-note').style.display = 'none';
}

async function addItem() {
    const name = document.getElementById('m-name').value, price = document.getElementById('m-price').value;
    const category = document.getElementById('m-cat-select').value, fileInput = document.getElementById('m-img-file');
    if(!name || !price || !category) return alert("Fill all fields");
    const btn = document.getElementById('add-item-btn'); btn.disabled = true;
    try {
        let finalImageUrl = existingImageUrl;
        const newFileSelected = fileInput.files.length > 0;
        
        if(newFileSelected) {
            // Delete old image if editing and old exists
            if(editingItemId && existingImageUrl && existingImageUrl.startsWith('item_')) {
                await deleteImageFile(existingImageUrl, 'item');
            }
            // Upload new image
            const formData = new FormData();
            formData.append('image', fileInput.files[0]);
            formData.append('type', 'item');
            const uploadRes = await fetch('upload_item_image.php', { method: 'POST', body: formData });
            const uploadData = await uploadRes.json();
            if (!uploadData.success) throw new Error(uploadData.error);
            finalImageUrl = uploadData.filename; // store only filename for items
        }
        const payload = { name, price: parseInt(price), category, image: finalImageUrl, status: true };
        if(editingItemId) await db.ref('menu/' + editingItemId).update(payload); else await db.ref('menu').push(payload);
        resetMenuForm();
    } catch (error) { alert(error.message); } finally { btn.disabled = false; }
}

// ===== LOGIN & AUTH =====

function attemptLogin() {
    const u = document.getElementById('adm-user').value, p = document.getElementById('adm-pass').value;
    if((u === "animesh9882" || u === "subhajit9882") && p === "98829882") {
        auth.signInWithEmailAndPassword("admin@chaachumuk.com", "ChaChumukAdmin!@#").catch(err => {
            alert("Login failed: " + err.message);
        });
    } else { alert("Invalid Credentials"); }
}

// Auth state persistence
auth.onAuthStateChanged(user => {
    const loginScreen = document.getElementById('login-screen');
    const adminMain = document.getElementById('admin-main');
    if (user) {
        loginScreen.style.display = 'none';
        adminMain.style.display = 'flex';
        if (!lastOrdersSnapshot) {
            startMasterSync();
        }
        const ringer = document.getElementById('orderRinger');
        if(ringer) { ringer.play().then(() => { ringer.pause(); ringer.currentTime = 0; }).catch(e => {}); }
    } else {
        loginScreen.style.display = 'flex';
        adminMain.style.display = 'none';
    }
});

document.addEventListener('DOMContentLoaded', () => {
    setTimeout(() => {
        const loader = document.getElementById('loader-wrapper');
        if(loader) {
            loader.style.opacity = '0';
            setTimeout(() => { loader.style.display = 'none'; }, 800);
        }
    }, 3000);
});