// assets/js/firebase-init.js
const firebaseConfig = {
    apiKey: "AIzaSyAmKXMQy_PQmtC6us4INrEk-eS6i-yeLnQ",
    authDomain: "cacf-d3b74.firebaseapp.com",
    databaseURL: "https://cacf-d3b74-default-rtdb.firebaseio.com",
    projectId: "cacf-d3b74",
    storageBucket: "cacf-d3b74.firebasestorage.app",
    messagingSenderId: "474635161120",
    appId: "1:474635161120:web:6d78d9481447550606f645"
};

firebase.initializeApp(firebaseConfig);
const auth = firebase.auth();
const db = firebase.database();