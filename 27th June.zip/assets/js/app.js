// assets/js/app.js
// Customer-side logic (cart, auth, menu, orders, checkout, maps, etc.)

// (Note: auth and db are defined globally via firebase-init.js)
// Global variables from original script
let currentLang = localStorage.getItem('appLang') || 'en';
let pendingLang = currentLang;
let cart = [];
try { const stored = localStorage.getItem('cc_cart'); if (stored) cart = JSON.parse(stored); } catch(e) { cart = []; }
let userData = {}, currentSubtotal = 0, finalDelFee = 0, currentCheckoutDistance = 0, latestMenuPrices = {};
let orderStatusTracker = {}; let isInitialLoad = true;
let isGuest = true;
let selectedPaymentMethod = 'online';
let savedAddressesModalContext = 'checkout';
let isDistanceCalculated = false;
let checkoutMap = null, checkoutMarker = null, checkoutAutocomplete = null, checkoutDistService = null;
const restCoords = { lat: 22.7285, lng: 87.86883 };
let manualPromoCode = '';
let manualPromoDiscount = 0;
let isPromoApplied = false;
let shopIsOpen = true;
let shopOpenTimeStr = '';
let shopCloseTimeStr = '';
let bannerInterval = null;
let currentBannerIdx = 0;
let menuItemsForSearch = [];
let currentSheetItem = null;
let globalPromoFired = false;

const langData = {
    en: { 
        wel: "Welcome", home: "Home", ord: "Orders", prof: "Profile", contact: "Get in Touch", call: "Call Support", wa: "WhatsApp Us", close: "Close", bucket: "Bucket", fname: "FULL NAME", fphone: "MOBILE NUMBER", proceed: "Proceed to Delivery", checkout: "Checkout", addr: "DELIVERY ADDRESS", dist: "Road Distance", min: "Min. Order Required", fee: "Delivery Fee", tot: "Total Pay", no_del: "We don't deliver here (Max 15km) or Invalid Location", low_val: "Add more items to meet Minimum Order!", pay_ok: "Payment Successful!", pay_fail: "Payment Failed", back: "Back to Orders", update: "Update Profile", logout: "Logout Account",
        search_hint: "Search for snacks...", login: "Login", google: "Google Login", new_user: "New user? Register", reg: "Register", create: "Create Account", personal: "Personal Details", p_name: "Full Name", p_phone: "Mobile Number", p_age: "Age", p_gen: "Gender", saved_addr: "Saved Address", add: "ADD", empty: "Bucket empty", subtotal: "Subtotal", make_pay: "Make Payment",
        survey_q: "How was your food?", survey_btn: "Submit Feedback", survey_thanks: "Thank you for your feedback!", phone_warn: "Mobile number not valid / remove if there is any 0 or +91 in place",
        txt_addr_curr: "Current Location", txt_addr_saved: "Saved Addresses", txt_prof_manage_addr: "Manage Saved Addresses", txt_modal_saved_title: "Saved Addresses", txt_pay_online: "Online Payment", txt_pay_cod: "Cash on Delivery", loc_title: "Location Permission Required", loc_subtext: "Granting location permission will ensure accurate address and hassle-free delivery.", loc_grant: "Grant Permission", cancel: "Cancel", shop_closed_banner: "Shop is currently closed. Operational hours: "
    },
    bn: { 
        wel: "স্বাগতম", home: "হোম", ord: "অর্ডার", prof: "প্রোফাইল", contact: "যোগাযোগ করুন", call: "কল করুন", wa: "হোয়াটসঅ্যাপ", close: "বন্ধ করুন", bucket: "ব্যাগ", fname: "আপনার নাম", fphone: "মোবাইল নম্বর", proceed: "ডেলিভারি এগিয়ে যান", checkout: "চেকআউট", addr: "ডেলিভারি ঠিকানা", dist: "রাস্তার দূরত্ব", min: "সর্বনিম্ন অর্ডার", fee: "ডেলিভারি খরচ", tot: "সব মিলিয়ে", no_del: "আমরা এখানে ডেলিভারি করি বিন্দু (সর্বোচ্চ ১৫কিমি)", low_val: "সর্বনিম্ন অর্ডারের জন্য আরও কিছু যোগ করুন!", pay_ok: "পেমেন্ট সফল হয়েছে!", pay_fail: "পেমেন্ট ব্যর্থ হয়েছে", back: "অর্ডারে ফিরে যান", update: "প্রোফাইল আপডেট", logout: "লগআউট",
        search_hint: "খাবার খুঁজুন...", login: "লগইন", google: "গুগল লগইন", new_user: "নতুন ইউজার? রেজিস্টার করুন", reg: "রেজিস্টার", create: "অ্যাকাউন্ট তৈরি করুন", personal: "ব্যগত তথ্য", p_name: "পুরো নাম", p_phone: "মোবাইল নম্বর", p_age: "বয়স", p_gen: "লিঙ্গ", saved_addr: "সেভ করা ঠিকানা", add: "যোগ করুন", empty: "ব্যাগ খালি", subtotal: "সাবটোটাল", make_pay: "পেমেন্ট করুন",
        survey_q: "খাবার কেমন ছিল?", survey_btn: "ফিডব্যাক দিন", survey_thanks: "আপনার ফিডব্যাকের জন্য ধন্যবাদ!", phone_warn: "সঠিক মোবাইল নাম্বার দাবান, যদি কোনো 0 বা +91 থাকে তাহলে সরান",
        txt_addr_curr: "বর্তমান অবস্থান", txt_addr_saved: "সংরক্ষিত ঠিকানা", txt_prof_manage_addr: "সংরক্ষিত ঠিকানা পরিচালনা করুন", txt_modal_saved_title: "সংরক্ষিত ঠিকানা", txt_pay_online: "অনলাইন পেমেন্ট", txt_pay_cod: "ক্যাশ অন ডেলিভারি", loc_title: "লোকেশন অনুমতি প্রয়োজন", loc_subtext: "সঠিক ঠিকানা এবং সহজে ডেলিভারির জন্য লোকেশনের অনুমতি দিন।", loc_grant: "অনুমতি দিন", cancel: "বাতিল করুন", shop_closed_banner: "দোকান বর্তমানে বন্ধ। সময়সূচী: "
    }
};

// --- Functions from original ---

function formatTime12(timeStr) {
    if(!timeStr) return "";
    const [h, m] = timeStr.split(':');
    let hours = parseInt(h);
    const ampm = hours >= 12 ? 'PM' : 'AM';
    hours = hours % 12 || 12;
    return `${hours}:${m} ${ampm}`;
}

function changeLang(l) { 
    currentLang = l; localStorage.setItem('appLang', l);
    const d = langData[l];
    document.getElementById('nav-home').innerText = d.home;
    document.getElementById('nav-orders').innerText = d.ord;
    document.getElementById('nav-profile').innerText = d.prof;
    document.getElementById('menu-search').placeholder = d.search_hint;
    document.getElementById('ui-orders-title').innerText = d.ord;
    document.getElementById('ui-profile-title').innerText = d.prof;
    document.getElementById('ui-bucket-title').innerText = d.bucket;
    document.getElementById('ui-checkout-title').innerText = d.checkout;
    document.getElementById('ui-contact-title').innerText = d.contact;
    document.getElementById('ui-call').innerText = d.call;
    document.getElementById('ui-wa').innerText = d.wa;
    document.getElementById('ui-close').innerText = d.close;
    document.getElementById('ui-login-title').innerText = d.login;
    document.getElementById('ui-login-btn').innerText = d.login;
    document.getElementById('ui-google-login').innerText = d.google;
    document.getElementById('ui-new-user').innerHTML = d.new_user;
    document.getElementById('ui-reg-title').innerText = d.reg;
    document.getElementById('ui-reg-btn').innerText = d.create;
    document.getElementById('ui-prof-pdet').innerText = d.personal;
    document.getElementById('lbl-pname').innerText = d.p_name;
    document.getElementById('lbl-pphone').innerText = d.p_phone;
    document.getElementById('lbl-page').innerText = d.p_age;
    document.getElementById('lbl-pgen').innerText = d.p_gen;
    document.getElementById('ui-prof-loc').innerText = d.addr;
    document.getElementById('ui-update-btn').innerText = d.update;
    document.getElementById('ui-logout-btn-text').innerText = d.logout;
    document.getElementById('lbl-fname').innerText = d.fname;
    document.getElementById('lbl-fphone').innerText = d.fphone;
    document.getElementById('bucket-phone-warning').innerText = d.phone_warn;
    document.getElementById('ui-proceed-btn').innerText = d.proceed;
    document.getElementById('lbl-addr').innerText = d.addr;
    document.getElementById('ui-dist').innerText = d.dist;
    document.getElementById('ui-min').innerText = d.min;
    document.getElementById('ui-fee').innerText = d.fee;
    document.getElementById('ui-tot').innerText = d.tot;
    document.getElementById('distance-error').innerText = d.no_del;
    document.getElementById('min-order-error').innerText = d.low_val;
    document.getElementById('ui-pay-ok').innerText = d.pay_ok;
    document.getElementById('ui-pay-fail').innerText = d.pay_fail;
    document.getElementById('ui-back-ord1').innerText = d.back;
    document.getElementById('ui-back-ord2').innerText = d.back;
    document.getElementById('ui-view-past').innerText = d.back;
    document.getElementById('ui-addr-curr').innerHTML = `<i class="fas fa-crosshairs"></i> ${d.txt_addr_curr}`;
    document.getElementById('ui-addr-saved').innerHTML = `<i class="fas fa-bookmark"></i> ${d.txt_addr_saved}`;
    document.getElementById('ui-prof-manage-addr').innerHTML = `<i class="fas fa-map-marked-alt"></i> ${d.txt_prof_manage_addr}`;
    document.getElementById('ui-modal-saved-title').innerText = d.txt_modal_saved_title;
    document.getElementById('pay-online').innerHTML = `<i class="fas fa-credit-card"></i> ${d.txt_pay_online}`;
    document.getElementById('pay-cod').innerHTML = `<i class="fas fa-money-bill-wave"></i> ${d.txt_pay_cod}`;
    if(selectedPaymentMethod === 'online') {
        document.getElementById('payment-btn').innerText = d.make_pay;
    } else {
        document.getElementById('payment-btn').innerText = (l === 'en' ? "Place Order (COD)" : "অর্ডার দিন (ক্যাশ)");
    }
    document.getElementById('loc-title').innerText = d.loc_title;
    document.getElementById('loc-subtext').innerText = d.loc_subtext;
    document.getElementById('loc-grant-btn').innerText = d.loc_grant;
    document.getElementById('ui-current-lang-text').innerText = (l === 'en') ? 'EN' : 'বাংলা';
    updateShopClosedUI();
    renderMenu(); 
}

function updateShopClosedUI() {
    const banners = document.querySelectorAll('.shop-closed-banner');
    const text = langData[currentLang].shop_closed_banner + `${formatTime12(shopOpenTimeStr)} to ${formatTime12(shopCloseTimeStr)}`;
    banners.forEach(b => b.innerHTML = `<i class="fas fa-clock"></i> ` + text);
    const cw = document.getElementById('shop-timings-display');
    if(cw) cw.innerText = `${formatTime12(shopOpenTimeStr)} to ${formatTime12(shopCloseTimeStr)}`;
}

function filterMenu(query) {
    const q = query.toLowerCase();
    document.querySelectorAll('.menu-item').forEach(el => {
        const name = el.querySelector('.menu-info b').innerText.toLowerCase();
        el.style.display = name.includes(q) ? 'flex' : 'none';
    });
    document.querySelectorAll('.category-header').forEach(header => {
        let sibling = header.nextElementSibling;
        let hasVisible = false;
        while (sibling && sibling.classList.contains('menu-item')) {
            if (sibling.style.display !== 'none') hasVisible = true;
            sibling = sibling.nextElementSibling;
        }
        header.style.display = hasVisible ? 'block' : 'none';
    });
}

function cycleSearchHints() {
    const input = document.getElementById('menu-search');
    if(!input || menuItemsForSearch.length === 0) return;
    let idx = 0;
    setInterval(() => {
        if(document.activeElement !== input && input.value === "") {
            const prefix = currentLang === 'en' ? "Search for" : "খুঁজুন";
            input.placeholder = `${prefix} "${menuItemsForSearch[idx]}"...`;
            idx = (idx + 1) % menuItemsForSearch.length;
        }
    }, 3000);
}

function requireLogin(callback) {
    if(isGuest) {
        document.getElementById('login-modal').style.display = 'flex';
        return false;
    }
    if(callback) callback();
    return true;
}

function switchAuthModal(to) {
    document.getElementById('login-modal').style.display = to === 'login' ? 'flex' : 'none';
    document.getElementById('signup-modal').style.display = to === 'signup' ? 'flex' : 'none';
}

function closeAuthModals() {
    document.getElementById('login-modal').style.display = 'none';
    document.getElementById('signup-modal').style.display = 'none';
}

function openContact() { document.getElementById('contact-modal').style.display = 'flex'; }
function closeContact() { document.getElementById('contact-modal').style.display = 'none'; }

function openLangModal() { pendingLang = currentLang; updateLangSelectionUI(); document.getElementById('lang-modal').style.display = 'flex'; }
function closeLangModal() { document.getElementById('lang-modal').style.display = 'none'; }
function selectLangOpt(l) { pendingLang = l; updateLangSelectionUI(); }
function updateLangSelectionUI() {
    document.getElementById('lang-opt-en').classList.toggle('active', pendingLang === 'en');
    document.getElementById('lang-opt-bn').classList.toggle('active', pendingLang === 'bn');
}
function applyLang() { changeLang(pendingLang); closeLangModal(); }

function checkLocationPermission() {
    if (navigator.geolocation && !isGuest) {
        navigator.geolocation.getCurrentPosition(
            () => { /* Granted */ }, 
            (error) => {
                if(error.code === error.PERMISSION_DENIED || error.code === error.POSITION_UNAVAILABLE) {
                    document.getElementById('location-overlay').style.display = 'flex';
                    document.getElementById('location-sheet').classList.add('open');
                }
            },
            { enableHighAccuracy: false, timeout: 5000, maximumAge: 0 }
        );
    }
}
function closeLocationPicker() { 
    document.getElementById('location-overlay').style.display = 'none'; 
    document.getElementById('location-sheet').classList.remove('open'); 
}
function grantLocation() { 
    if(navigator.geolocation) { 
        const btn = document.getElementById('loc-grant-btn');
        const origText = btn.innerText;
        btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
        navigator.geolocation.getCurrentPosition(
            pos => { 
                btn.innerText = origText;
                closeLocationPicker(); 
                if(document.getElementById('checkout-page').classList.contains('active')) {
                    triggerLiveLocation();
                }
            }, 
            (err) => {
                btn.innerText = origText;
                if(err.code === 2) alert("Please turn on your device GPS/Location.");
                else alert("Please enable location manually from browser settings."); 
            },
            { timeout: 10000, enableHighAccuracy: true }
        ); 
    } 
}

function saveCurrentCheckoutAddress() {
    const addrText = document.getElementById('checkout-addr-text').value.trim();
    if(!addrText) return alert("Please select a valid address first.");
    if(!checkoutMarker) return alert("Location not pinned on map.");
    const pos = checkoutMarker.getPosition();
    const addrObj = { fullAddress: addrText, lat: pos.lat(), lng: pos.lng() };
    db.ref(`users/${auth.currentUser.uid}/saved_addresses`).push(addrObj).then(() => {
        alert("Address saved successfully for future orders!");
    }).catch(e => alert("Error saving address: " + e.message));
}

function openSavedAddressesModal(context) {
    savedAddressesModalContext = context;
    fetchSavedAddressesList();
    document.getElementById('saved-addr-modal').style.display = 'block';
    document.getElementById('detail-overlay').style.display = 'flex'; 
    document.getElementById('saved-addr-modal').classList.add('open');
}
function closeSavedAddressesModal() {
    document.getElementById('detail-overlay').style.display = 'none';
    document.getElementById('saved-addr-modal').classList.remove('open');
}

function fetchSavedAddressesList() {
    const list = document.getElementById('saved-addr-list-container');
    list.innerHTML = '<div style="text-align:center; color:#888;"><i class="fas fa-spinner fa-spin"></i> Loading...</div>';
    db.ref(`users/${auth.currentUser.uid}/saved_addresses`).once('value', snap => {
        list.innerHTML = '';
        if(!snap.exists()) {
            list.innerHTML = '<p style="text-align:center; color:#999; font-size:13px; margin-bottom:15px;">No saved addresses found.</p>';
            return;
        }
        snap.forEach(child => {
            const d = child.val();
            const key = child.key;
            list.innerHTML += `
                <div class="saved-addr-card" onclick="selectSavedAddress('${key}')">
                    <h4><i class="fas fa-home" style="color:var(--primary); margin-right:5px;"></i> Address</h4>
                    <p>${d.fullAddress}</p>
                    <div class="addr-actions">
                        <i class="fas fa-trash act-del" onclick="event.stopPropagation(); deleteAddress('${key}')"></i>
                    </div>
                </div>
            `;
        });
    });
}

function deleteAddress(key) {
    if(confirm("Are you sure you want to delete this address?")) {
        db.ref(`users/${auth.currentUser.uid}/saved_addresses/${key}`).remove().then(() => fetchSavedAddressesList());
    }
}

function selectSavedAddress(key) {
    if(savedAddressesModalContext === 'checkout') {
        db.ref(`users/${auth.currentUser.uid}/saved_addresses/${key}`).once('value', s => {
            const d = s.val();
            if(d && checkoutMap && d.lat && d.lng) {
                document.getElementById('checkout-addr-text').value = d.fullAddress;
                isDistanceCalculated = false;
                const pBtn = document.getElementById('payment-btn');
                if(pBtn) { pBtn.disabled = true; pBtn.style.display = 'none'; }
                document.getElementById('checkout-dist-val').innerText = "Calculating...";
                const newPos = new google.maps.LatLng(d.lat, d.lng);
                checkoutMarker.setPosition(newPos);
                checkoutMap.panTo(newPos);
                checkoutMap.setZoom(16);
                calculateDistance();
            }
            closeSavedAddressesModal();
        });
    }
}

function calculateDistance() {
    if(!checkoutMarker || !checkoutDistService) return;
    isDistanceCalculated = false;
    const pBtn = document.getElementById('payment-btn');
    if(pBtn) { pBtn.disabled = true; pBtn.style.display = 'none'; }
    document.getElementById('checkout-map-loader').style.display = 'flex';
    const dest = checkoutMarker.getPosition();
    const origin = new google.maps.LatLng(restCoords.lat, restCoords.lng);
    checkoutDistService.getDistanceMatrix({
        origins: [origin], destinations: [dest], travelMode: 'DRIVING'
    }, (res, status) => {
        document.getElementById('checkout-map-loader').style.display = 'none';
        if(status === 'OK' && res.rows[0].elements[0].status === 'OK') {
            currentCheckoutDistance = res.rows[0].elements[0].distance.value / 1000;
            isDistanceCalculated = true;
            renderCheckoutTotals();
        } else {
            currentCheckoutDistance = 0; 
            isDistanceCalculated = true;
            renderCheckoutTotals();
        }
    });
}

async function applyPromoCode() {
    const msg = document.getElementById('promo-msg');
    const codeInput = document.getElementById('promo-input-box').value.trim().toUpperCase();
    if(!codeInput) {
        msg.innerText = "Please enter a promocode."; msg.style.color = "var(--danger)";
        return;
    }
    msg.innerText = "Checking..."; msg.style.color = "#888";
    try {
        const s = await db.ref('promocode/live/' + codeInput).once('value');
        if(!s.exists()) {
            msg.innerText = "Invalid or expired promocode."; msg.style.color = "var(--danger)";
            resetPromoState();
            return;
        }
        const pData = s.val();
        const uSnap = await db.ref(`promo_usage/${auth.currentUser.uid}/${codeInput}`).once('value');
        if(uSnap.exists() && uSnap.val() === true) {
            msg.innerText = "You have already used this promocode."; msg.style.color = "var(--danger)";
            resetPromoState();
            return;
        }
        if(pData.userType === 'new_user' && (userData.orderCount > 0)) {
            msg.innerText = "This promocode is only for first-time customers."; msg.style.color = "var(--danger)";
            resetPromoState();
            return;
        }
        let rawDiscount = 0;
        let pType = pData.type || 'flat';
        let pAmount = parseFloat(pData.amount) || 0;
        if(pType === 'percent') {
            rawDiscount = (currentSubtotal * pAmount) / 100;
        } else {
            rawDiscount = pAmount;
        }
        manualPromoCode = codeInput;
        manualPromoDiscount = rawDiscount;
        isPromoApplied = true;
        msg.innerText = "Promocode applied successfully!"; msg.style.color = "var(--success)";
        renderCheckoutTotals();
    } catch (error) {
        console.error("Promo error:", error);
        msg.innerText = "Error applying promocode."; msg.style.color = "var(--danger)";
        resetPromoState();
    }
}

function resetPromoState() {
    manualPromoCode = '';
    manualPromoDiscount = 0;
    isPromoApplied = false;
    document.getElementById('promo-input-box').value = '';
    renderCheckoutTotals();
}

function renderCheckoutTotals() {
    if(!checkoutMarker) return;
    const pBtn = document.getElementById('payment-btn');
    const distErr = document.getElementById('distance-error');
    const minErr = document.getElementById('min-order-error');
    const detailsBlock = document.getElementById('delivery-details-block');
    const promoRow = document.getElementById('promo-display-row');
    const shopWarning = document.getElementById('shop-closed-warning');
    if(detailsBlock) detailsBlock.style.display = 'none';
    if(promoRow) promoRow.style.display = 'none';
    distErr.style.display = 'none';
    minErr.style.display = 'none';
    if(shopWarning) shopWarning.style.display = 'none';
    if(pBtn) { pBtn.style.display = 'none'; pBtn.disabled = true; }
    if(!shopIsOpen) {
        if(shopWarning) shopWarning.style.display = 'block';
        return;
    }
    if(!isDistanceCalculated) {
        document.getElementById('checkout-dist-val').innerText = "Calculating...";
        return;
    }
    if(currentCheckoutDistance <= 0.05 || isNaN(currentCheckoutDistance)) {
        distErr.style.display = 'block';
        document.getElementById('checkout-dist-val').innerText = "Invalid Route";
        return;
    }
    document.getElementById('checkout-dist-val').innerText = currentCheckoutDistance.toFixed(2) + " km";
    const slabKey = Math.ceil(currentCheckoutDistance);
    if(currentCheckoutDistance > 15 || slabKey > 15) {
        distErr.style.display = 'block';
        return;
    }
    if(detailsBlock) detailsBlock.style.display = 'block';
    const deliverySlabs = { 0:[10,0], 1:[149,20], 2:[149,20], 3:[299,30], 4:[299,40], 5:[299,50], 6:[499,60], 7:[499,70], 8:[499,80], 9:[499,80], 10:[499,80], 11:[649,85], 12:[649,90], 13:[649,95], 14:[649,100], 15:[649,100] };
    const [minOrder, delCharge] = deliverySlabs[slabKey] || deliverySlabs[0];
    document.getElementById('checkout-min-val').innerText = "₹" + minOrder;
    document.getElementById('checkout-del-fee').innerText = "₹" + delCharge;
    finalDelFee = delCharge;
    let tot = currentSubtotal + delCharge;
    if(isPromoApplied && manualPromoDiscount > 0) {
        let actualDiscount = Math.min(manualPromoDiscount, tot);
        tot = Math.max(0, tot - actualDiscount);
        if(promoRow) {
            promoRow.style.display = 'flex';
            document.getElementById('promo-discount-val').innerText = '-₹' + actualDiscount.toFixed(2);
        }
    } else {
        if(promoRow) promoRow.style.display = 'none';
    }
    document.getElementById('checkout-total-pay').innerText = "₹" + tot.toFixed(2);
    if(currentSubtotal < minOrder) {
        minErr.style.display = 'block';
        if(pBtn) { pBtn.style.display = 'none'; pBtn.disabled = true; }
    } else {
        minErr.style.display = 'none';
        if(pBtn) { pBtn.style.display = 'block'; pBtn.disabled = false; }
    }
}

function initBanners() {
    const track = document.getElementById('banner-track');
    const section = document.getElementById('banner-section');
    db.ref('settings/banner_enabled').on('value', snap => {
        const enabled = snap.val() !== false;
        section.style.display = enabled ? 'block' : 'none';
    });
    db.ref('banners').on('value', snap => {
        track.innerHTML = "";
        let count = 0;
        snap.forEach(b => {
            track.innerHTML += `<img src="${b.val().url}" class="banner-slide">`;
            count++;
        });
        if(bannerInterval) clearInterval(bannerInterval);
        if(count > 1) {
            currentBannerIdx = 0;
            bannerInterval = setInterval(() => {
                currentBannerIdx = (currentBannerIdx + 1) % count;
                track.style.transform = `translateX(-${currentBannerIdx * 100}%)`;
            }, 4000);
        } else {
            track.style.transform = `translateX(0)`;
        }
    });
}

function renderMenu() { 
    db.ref('menu').on('value', snap => {
        const cont = document.getElementById('menu-container');
        cont.innerHTML = ""; menuItemsForSearch = [];
        latestMenuPrices = {}; 
        const addText = langData[currentLang].add;
        let cats = {};
        snap.forEach(c => {
            const i = c.val(); 
            if(!i) return;
            const cat = i.category || "General";
            if(!cats[cat]) cats[cat] = [];
            cats[cat].push({ ...i, key: c.key });
            latestMenuPrices[c.key] = parseFloat(i.price);
        });
        for(let name in cats) {
            cont.innerHTML += `<div class="category-header">${name}</div>`;
            cats[name].forEach(i => {
                const dName = (currentLang === 'bn') ? (i.name_bn || i.name) : (i.name_en || i.name);
                menuItemsForSearch.push(dName);
                const isAvail = (i.status !== false);
                const globalClosed = !shopIsOpen;
                const disabledClass = (!isAvail || globalClosed) ? 'disabled' : '';
                let imgSrc = i.image || "";
                if(imgSrc && !imgSrc.startsWith('http')) imgSrc = `itemimages/${imgSrc}`;
                if(!imgSrc) imgSrc = 'https://via.placeholder.com/100?text=Food';
                cont.innerHTML += `<div class="menu-item ${disabledClass}"><img src="${imgSrc}" class="menu-thumb" onclick='openDetails(${JSON.stringify(i).replace(/'/g, "\\'")})'><div class="menu-info" onclick='openDetails(${JSON.stringify(i).replace(/'/g, "\\'")})'><b>${dName}</b><br><span style="color:var(--primary); font-weight:700;">₹${i.price}</span></div><button class="btn-add" onclick="event.stopPropagation(); addToCart('${i.key}','${dName.replace(/'/g, "\\'")}',${i.price}, this)" ${globalClosed ? 'disabled' : ''}><i class="fas fa-plus"></i> ${addText}</button></div>`;
            });
        }
        if(!shopIsOpen) {
            cont.innerHTML = `<div class="shop-closed-banner"></div>` + cont.innerHTML;
        }
        cont.innerHTML += `
        <div style="margin: 20px 15px 0 15px; padding: 28px 22px; background: white; border-radius: 20px; border: 1px solid #eee; box-shadow: 0 2px 12px rgba(0,0,0,0.04); text-align: center;">
            <div style="width: 38px; height: 3px; background: var(--primary-grad); border-radius: 2px; margin: 0 auto 16px auto;"></div>
            <h3 style="font-size: 17px; font-weight: 700; color: #1a1a1a; margin-bottom: 6px; font-family: 'Montserrat', sans-serif; letter-spacing: 0.3px;">Welcome to Chaachumuk</h3>
            <p style="font-size: 12px; color: #ff9f1c; font-weight: 600; margin-bottom: 14px; letter-spacing: 0.5px; text-transform: uppercase; font-size: 10px;">Where Flavor Meets Comfort</p>
            <p style="font-size: 12.5px; color: #555; line-height: 1.9; margin-bottom: 14px;">From sizzling favorites to soul-satisfying meals, we bring you freshly prepared dishes crafted with quality ingredients, rich taste, and a touch of happiness in every bite. Whether you are craving a quick snack, a hearty meal, or a late-night treat, Chaachumuk is here to serve delicious moments straight to your doorstep.</p>
            <p style="font-size: 12px; color: #777; line-height: 1.7; margin-bottom: 18px; font-style: italic;">Fast delivery, irresistible taste, and an experience you will always come back for.</p>
            <div style="display: inline-block; padding: 8px 20px; border: 1.5px solid var(--primary); border-radius: 20px;">
                <span style="font-size: 12px; font-weight: 700; color: var(--primary); letter-spacing: 1px; text-transform: uppercase;">Eat Fresh &nbsp;|&nbsp; Feel Happy &nbsp;|&nbsp; Only at Chaachumuk</span>
            </div>
            <div style="width: 38px; height: 3px; background: var(--primary-grad); border-radius: 2px; margin: 16px auto 0 auto;"></div>
        </div>
        <div style="text-align:center; padding: 20px 20px 25px 20px; font-size: 11px; color: #888; line-height: 1.6; border-top: 1px solid #eee; margin-top: 20px;">You&#39;re now part of our family&#8212;by using our services, you agree to our<br><a href="https://chaachumuk.com/termsofuse.php" style="color:var(--primary); font-weight:600; text-decoration:none;">Terms &amp; Conditions</a> and <a href="https://chaachumuk.com/privacypolicy.php" style="color:var(--primary); font-weight:600; text-decoration:none;">Privacy Policy</a>.</div>`;
        updateShopClosedUI();
        let cartUpdated = false;
        cart.forEach(item => {
            if (latestMenuPrices[item.id] !== undefined && latestMenuPrices[item.id] !== item.price) {
                item.price = latestMenuPrices[item.id];
                cartUpdated = true;
            }
        });
        if (cartUpdated) {
            saveCart();
            if (document.getElementById('cart-page').classList.contains('active')) renderCartPage();
            if (document.getElementById('checkout-page').classList.contains('active')) renderCheckout();
        }
    }); 
}

function selectPay(method) {
    selectedPaymentMethod = method;
    document.getElementById('pay-online').classList.toggle('active', method === 'online');
    document.getElementById('pay-cod').classList.toggle('active', method === 'cod');
    const btn = document.getElementById('payment-btn');
    if(method === 'online') {
        btn.innerText = currentLang === 'en' ? langData.en.make_pay : langData.bn.make_pay;
    } else {
        btn.innerText = currentLang === 'en' ? "Place Order (COD)" : "অর্ডার দিন (ক্যাশ)";
    }
}

async function processPaymentAction() {
    if(!requireLogin()) return;
    if(!shopIsOpen) {
        alert("Shop is currently closed. You cannot place orders at this moment.");
        return;
    }
    if(currentCheckoutDistance <= 0.05) {
        alert("Invalid distance. Please set a valid delivery location.");
        return;
    }
    if(selectedPaymentMethod === 'online') {
        initiateRazorpay();
    } else {
        placeCodOrder();
    }
}

function refreshOrders() {
    if (auth.currentUser) {
        db.ref('orders').orderByChild('userId').equalTo(auth.currentUser.uid).off();
        fetchOrders();
    }
}

async function placeCodOrder() {
    const pBtn = document.getElementById('payment-btn');
    const originalText = pBtn.innerText;
    pBtn.innerHTML = '<i class="fas fa-circle-notch fa-spin"></i> Processing...';
    pBtn.disabled = true;
    try {
        const verifiedSubtotal = currentSubtotal;
        const verifiedDelFee = finalDelFee;
        const appliedDiscount = isPromoApplied ? manualPromoDiscount : 0;
        const serverPromoCode = isPromoApplied ? manualPromoCode : null;
        let verifiedTotal = Math.max(0, verifiedSubtotal + verifiedDelFee - appliedDiscount);
        const pos = checkoutMarker.getPosition();
        const oId = 'ORD-' + Date.now(); 
        const orderData = { 
            userId: auth.currentUser.uid, 
            customerName: document.getElementById('bucket-user-name').value, 
            customerPhone: document.getElementById('bucket-phone').value, 
            items: cart, 
            total: verifiedTotal, 
            deliveryCharge: verifiedDelFee, 
            subtotal: verifiedSubtotal, 
            promoCode: serverPromoCode,
            promoDiscount: appliedDiscount,
            discount: appliedDiscount,
            address: document.getElementById('checkout-addr-text').value, 
            lat: pos.lat(), 
            lng: pos.lng(), 
            paymentId: "COD", 
            paymentMethod: "Cash on Delivery",
            status: 'Placed', 
            timestamp: Date.now() 
        };
        await db.ref('orders/' + oId).set(orderData);
        const currentCount = userData.orderCount || 0;
        await db.ref('users/' + auth.currentUser.uid + '/orderCount').set(currentCount + 1);
        userData.orderCount = currentCount + 1;
        if(serverPromoCode) {
            await db.ref(`promo_usage/${auth.currentUser.uid}/${serverPromoCode}`).set(true);
        }
        cart = []; 
        saveCart(); 
        resetPromoState();
        playStatus('success');
        refreshOrders();
        showPage('cod-success-page'); 
        pBtn.innerText = originalText;
        pBtn.disabled = false;
    } catch (err) {
        console.error("Order Error:", err);
        alert("Error placing order. Please check your data and try again.");
        pBtn.innerText = originalText;
        pBtn.disabled = false;
    }
}

async function initiateRazorpay() {
    const pBtn = document.getElementById('payment-btn');
    const originalText = pBtn.innerText;
    pBtn.innerHTML = '<i class="fas fa-circle-notch fa-spin"></i> Securing payment...';
    pBtn.disabled = true;
    try {
        const verifiedSubtotal = currentSubtotal;
        const verifiedDelFee = finalDelFee;
        const appliedDiscount = isPromoApplied ? manualPromoDiscount : 0;
        const serverPromoCode = isPromoApplied ? manualPromoCode : null;
        let verifiedTotal = Math.max(0, verifiedSubtotal + verifiedDelFee - appliedDiscount);
        if (verifiedTotal <= 0) {
            handlePayment('FREE_ORDER', 'ORD-' + Date.now(), 'FREE_SIGNATURE', verifiedSubtotal, verifiedDelFee, appliedDiscount, serverPromoCode);
            return;
        }
        const dummyOrderId = 'ORD-' + Date.now();
        const opt = {
            "key": "rzp_live_SmOKAPM9jeBpYH", // from config
            "amount": Math.round(verifiedTotal * 100), 
            "currency": "INR",
            "name": "Cha A Chumuk",
            "handler": function(res) { 
                handlePayment(res.razorpay_payment_id, dummyOrderId, res.razorpay_signature || "NO_SIGNATURE", verifiedSubtotal, verifiedDelFee, appliedDiscount, serverPromoCode); 
            },
            "prefill": {
                "name": document.getElementById('bucket-user-name').value,
                "contact": document.getElementById('bucket-phone').value
            },
            "theme": { "color": "#ff9f1c" },
            "modal": {
                "ondismiss": function() {
                    pBtn.innerText = originalText;
                    pBtn.disabled = false;
                    showPage('payment-fail-page');
                }
            }
        };
        new Razorpay(opt).open();
    } catch (err) {
        console.error("Payment Error:", err);
        alert("Payment gateway connection error. Please try again.");
        pBtn.innerText = originalText;
        pBtn.disabled = false;
    }
}

function handlePayment(payId, rzpOrderId, rzpSignature, verifiedSubtotal, verifiedDelFee, serverPromoDiscount, serverPromoCode) {
    const oId = 'ORD-' + Date.now(); 
    const pos = checkoutMarker.getPosition();
    const appliedDiscount = serverPromoDiscount || 0;
    let verifiedTotal = verifiedSubtotal + verifiedDelFee - appliedDiscount;
    if(verifiedTotal < 0) verifiedTotal = 0;
    const orderData = { 
        userId: auth.currentUser.uid, 
        customerName: document.getElementById('bucket-user-name').value, 
        customerPhone: document.getElementById('bucket-phone').value, 
        items: cart, 
        total: verifiedTotal, 
        deliveryCharge: verifiedDelFee, 
        subtotal: verifiedSubtotal, 
        promoCode: serverPromoCode || null,
        promoDiscount: appliedDiscount,
        discount: appliedDiscount,
        address: document.getElementById('checkout-addr-text').value, 
        lat: pos.lat(), 
        lng: pos.lng(), 
        paymentId: payId, 
        razorpayOrderId: rzpOrderId,
        razorpaySignature: rzpSignature,
        paymentMethod: "Online",
        status: 'Paid', 
        timestamp: Date.now() 
    };
    db.ref('orders/' + oId).set(orderData).then(() => { 
        const currentCount = userData.orderCount || 0;
        db.ref('users/' + auth.currentUser.uid + '/orderCount').set(currentCount + 1);
        userData.orderCount = currentCount + 1;
        if(serverPromoCode) {
            db.ref(`promo_usage/${auth.currentUser.uid}/${serverPromoCode}`).set(true);
        }
        cart = []; 
        saveCart(); 
        resetPromoState();
        playStatus('success');
        refreshOrders();
        showPage('payment-success-page'); 
    });
}

function playStatus(type) { const audio = new Audio('assets/audio/' + type + '.mp3'); audio.play().catch(()=>{}); }

function showPage(pId, el) { 
    if(['orders-page', 'profile-page', 'cart-page', 'checkout-page'].includes(pId)) {
        if(!requireLogin()) return;
    }
    document.querySelectorAll('.page').forEach(p=>p.classList.remove('active')); 
    document.getElementById(pId).classList.add('active'); 
    if(el){ document.querySelectorAll('.nav-item').forEach(n=>n.classList.remove('active')); el.classList.add('active'); } 
    const header = document.getElementById('global-header');
    if(['home-page', 'orders-page', 'profile-page', 'cart-page', 'checkout-page'].includes(pId)) {
        header.style.display = 'block';
        header.querySelector('.search-wrapper').style.display = (pId === 'home-page') ? 'block' : 'none';
    } else {
        header.style.display = 'none';
    }
    if(pId==='home-page') { renderMenu(); initBanners(); }
    if(pId==='cart-page') { renderCartPage(); checkLocationPermission(); }
    if(pId==='checkout-page') { 
        const pBtn = document.getElementById('payment-btn');
        if(pBtn) { pBtn.disabled = true; pBtn.style.display = 'none'; }
        initMap(); 
        renderCheckout(); 
        if (!document.getElementById('checkout-addr-text').value) {
            triggerLiveLocation();
        }
    }
    if(pId==='orders-page') {
        db.ref('orders').orderByChild('userId').equalTo(auth.currentUser.uid).off();
        fetchOrders(); 
    }
    window.scrollTo(0,0);
}

function saveCart() { localStorage.setItem('cc_cart', JSON.stringify(cart)); const count = cart.reduce((acc, obj) => acc + (obj.qty || 0), 0); document.getElementById('bucket-badge').innerText = count; document.getElementById('floating-bucket').style.display = count > 0 ? 'flex' : 'none'; }
function updateCartQty(id, delta) { const item = cart.find(i => i.id === id); if(item) { item.qty += delta; if(item.qty <= 0) cart = cart.filter(i => i.id !== id); saveCart(); renderCartPage(); } }
function validateBucketPhone() { 
    const phone = document.getElementById('bucket-phone').value; 
    const btn = document.getElementById('ui-proceed-btn'); 
    const warn = document.getElementById('bucket-phone-warning');
    const isValid = /^\d{10}$/.test(phone);
    if (phone !== "" && !isValid) warn.style.display = 'block'; else warn.style.display = 'none';
    btn.disabled = !isValid || cart.length === 0; 
}

function renderCartPage() { 
    const cont = document.getElementById('bucket-items-list'); cont.innerHTML = ""; currentSubtotal = 0; 
    if(cart.length === 0) { 
        cont.innerHTML = `<p style='text-align:center;padding:20px;color:#999;'>${langData[currentLang].empty}</p>`; 
        document.getElementById('ui-proceed-btn').disabled = true; return; 
    } 
    cart.forEach(i => { const total = i.price * i.qty; currentSubtotal += total; cont.innerHTML += `<div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px;"><div><b>${i.name}</b><br><small>₹${i.price}</small></div><div style="display:flex; align-items:center; gap:10px;"><div class="qty-box"><button onclick="updateCartQty('${i.id}',-1)">-</button><span>${i.qty}</span><button onclick="updateCartQty('${i.id}',1)">+</button></div><b style="min-width:50px; text-align:right;">₹${total}</b></div></div>`; }); 
    cont.innerHTML += `<hr style="border:none; border-top:1px dashed #eee; margin:10px 0;"><div style="text-align:right; font-weight:700; color:var(--primary); font-size:16px;">${langData[currentLang].subtotal}: ₹${currentSubtotal}</div>`; 
    document.getElementById('bucket-user-name').value = userData.name || ""; document.getElementById('bucket-phone').value = userData.phone || ""; validateBucketPhone();
}

function renderCheckout() { 
    const sum = document.getElementById('checkout-summary'); 
    const sumTitle = currentLang === 'en' ? "Order Summary" : "অর্ডার সামারি";
    sum.innerHTML = `<h3>${sumTitle}</h3>`; 
    cart.forEach(i => { sum.innerHTML += `<div style="display:flex; justify-content:space-between; font-size:13px; color:#666;"><span>${i.name} x ${i.qty}</span><span>₹${i.price*i.qty}</span></div>`; }); 
    sum.innerHTML += `<hr style="border:none; border-top:1px solid #eee; margin:8px 0;"><div style="text-align:right; font-weight:700;">${langData[currentLang].subtotal}: ₹${currentSubtotal}</div>`;
    calculateDistance(); 
}

function proceedToCheckout() { 
    const phone = document.getElementById('bucket-phone').value; 
    if(!/^\d{10}$/.test(phone) || cart.length === 0) return alert("Valid 10-digit mobile number required."); 
    if(!shopIsOpen) {
        alert("Shop is currently closed. You cannot place orders at this moment.");
        return;
    }
    showPage('checkout-page'); 
}

function triggerLiveLocation() { 
    document.getElementById('checkout-map-loader').style.display = 'flex';
    document.getElementById('checkout-addr-loader').style.display = 'flex';
    isDistanceCalculated = false;
    const pBtn = document.getElementById('payment-btn');
    if(pBtn) { pBtn.disabled = true; pBtn.style.display = 'none'; }
    document.getElementById('checkout-dist-val').innerText = "Locating...";
    if(navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(pos => { 
            const newPos = new google.maps.LatLng(pos.coords.latitude, pos.coords.longitude);
            checkoutMarker.setPosition(newPos); 
            checkoutMap.panTo(newPos); 
            getAddress(pos.coords.latitude, pos.coords.longitude); 
            calculateDistance(); 
        }, err => {
            document.getElementById('checkout-map-loader').style.display = 'none';
            document.getElementById('checkout-addr-loader').style.display = 'none';
            document.getElementById('checkout-dist-val').innerText = "Failed";
            if(err.code === err.PERMISSION_DENIED || err.code === err.POSITION_UNAVAILABLE) {
                checkLocationPermission(); 
            }
        }, { enableHighAccuracy: true, timeout: 8000, maximumAge: 0 }); 
    }
}

function initMap() { 
    document.getElementById('checkout-map-loader').style.display = 'none';
    document.getElementById('checkout-addr-loader').style.display = 'none';
    if(!checkoutMap) { 
        checkoutMap = new google.maps.Map(document.getElementById('checkout-map'), { 
            center: restCoords, zoom: 15, disableDefaultUI: true, gestureHandling: "greedy" 
        }); 
        checkoutMarker = new google.maps.Marker({
            position: restCoords, map: checkoutMap, draggable: true, animation: google.maps.Animation.DROP
        });
        checkoutDistService = new google.maps.DistanceMatrixService();
        const circle = new google.maps.Circle({ center: restCoords, radius: 25000 });
        checkoutAutocomplete = new google.maps.places.Autocomplete(document.getElementById('checkout-addr-text'), {
            bounds: circle.getBounds(), strictBounds: true
        });
        checkoutAutocomplete.addListener('place_changed', () => {
            const place = checkoutAutocomplete.getPlace();
            if(place.geometry) {
                checkoutMarker.setPosition(place.geometry.location);
                checkoutMap.panTo(place.geometry.location);
                calculateDistance();
            }
        });
        checkoutMarker.addListener('dragend', () => { 
            document.getElementById('checkout-addr-loader').style.display = 'flex';
            const pos = checkoutMarker.getPosition();
            getAddress(pos.lat(), pos.lng()); 
            calculateDistance(); 
        }); 
    } else { 
        google.maps.event.trigger(checkoutMap, "resize");
    } 
    calculateDistance(); 
}

function getAddress(lat, lng) { 
    const geocoder = new google.maps.Geocoder();
    geocoder.geocode({ location: { lat, lng } }, (results, status) => {
        document.getElementById('checkout-addr-loader').style.display = 'none';
        if(status === 'OK' && results[0]) {
            document.getElementById('checkout-addr-text').value = results[0].formatted_address;
        } else {
            document.getElementById('checkout-addr-text').value = `Pinned: ${lat.toFixed(5)}, ${lng.toFixed(5)}`;
        }
    });
}

function addToCart(id, name, price, btnEl) { 
    if(!requireLogin()) return;
    if(!shopIsOpen) {
        alert("Shop is currently closed. You cannot add items at this moment.");
        return;
    }
    const existing = cart.find(i => i.id === id); 
    if(existing) existing.qty++; else cart.push({id, name, price, qty: 1}); 
    saveCart(); 
    if(btnEl) { 
        const r = btnEl.getBoundingClientRect(), cr = document.getElementById('floating-bucket').getBoundingClientRect(); 
        const g = document.createElement('div'); 
        g.className = 'ghost-item'; 
        g.innerHTML = '<i class="fas fa-plus"></i>';
        g.style.top = r.top + 'px'; g.style.left = r.left + 'px'; 
        document.body.appendChild(g); 
        setTimeout(() => { g.style.transform = `translate(${cr.left - r.left}px, ${cr.top - r.top}px) rotate(360deg) scale(0.1)`; g.style.opacity = '0'; }, 10); 
        setTimeout(() => {
            const bucket = document.getElementById('floating-bucket');
            bucket.style.transform = "scale(1.3)";
            setTimeout(() => bucket.style.transform = "scale(1)", 200);
            g.remove();
        }, 800); 
    } 
}

function openDetails(item) { 
    if(!requireLogin()) return;
    currentSheetItem = item; 
    const dName = (currentLang === 'bn') ? (item.name_bn || item.name) : (item.name_en || item.name); 
    let imgSrc = item.image || "";
    if(imgSrc && !imgSrc.startsWith('http')) imgSrc = `itemimages/${imgSrc}`;
    if(!imgSrc) imgSrc = 'https://via.placeholder.com/300?text=No+Image';
    document.getElementById('sheet-img').src = imgSrc;
    document.getElementById('sheet-name').innerText = dName; 
    document.getElementById('sheet-price').innerText = '₹' + item.price; 
    document.getElementById('detail-overlay').style.display = 'flex'; 
    document.getElementById('item-sheet').classList.add('open'); 
}

function closeDetails() { 
    document.getElementById('detail-overlay').style.display = 'none'; 
    document.getElementById('item-sheet').classList.remove('open'); 
    document.getElementById('saved-addr-modal').classList.remove('open'); 
}

function addFromSheet() { if(currentSheetItem) { const dName = (currentLang === 'bn') ? (currentSheetItem.name_bn || currentSheetItem.name) : (currentSheetItem.name_en || currentSheetItem.name); addToCart(currentSheetItem.key, dName, currentSheetItem.price, null); closeDetails(); } }

function setRating(orderId, val) {
    const container = document.getElementById(`survey-${orderId}`);
    if(!container) return;
    container.dataset.selected = val;
    const stars = container.querySelectorAll('.star-icon');
    stars.forEach((s, idx) => {
        if(idx < val) s.classList.add('active');
        else s.classList.remove('active');
    });
}

function submitSurvey(orderId) {
    const container = document.getElementById(`survey-${orderId}`);
    const rating = parseInt(container.dataset.selected || 0);
    const feedback = document.getElementById(`feedback-${orderId}`).value;
    if(rating === 0) return alert("Please select a star rating");
    db.ref(`orders/${orderId}/survey`).set({ rating: rating, feedback: feedback, timestamp: Date.now() }).then(() => {
        container.innerHTML = `<p style="color:var(--success); font-weight:700; font-size:13px;"><i class="fas fa-check-circle"></i> ${langData[currentLang].survey_thanks}</p>`;
        container.classList.add('submitted');
    });
}

function fetchOrders() { 
    db.ref('orders').orderByChild('userId').equalTo(auth.currentUser.uid).on('value', snap => { 
        const ac = document.getElementById('active-orders'), hc = document.getElementById('history-orders'); 
        ac.innerHTML = ""; hc.innerHTML = ""; 
        if(!snap.exists()) {
            ac.innerHTML = '<div class="card" style="text-align:center; color:#888;"><i class="fas fa-receipt"></i><br>No orders found.<br>Place your first order now!</div>';
            hc.innerHTML = '';
            return;
        }
        let hasActive = false;
        snap.forEach(c => { 
            const o = c.val(); const orderId = c.key; const d = new Date(o.timestamp).toLocaleString(); const currentStatus = o.status || 'Placed'; 
            if (!isInitialLoad) {
                if (orderStatusTracker[orderId] && orderStatusTracker[orderId] !== currentStatus) {
                    const notifySound = new Audio('assets/audio/notification.mp3');
                    notifySound.play().catch(e => {});
                }
            }
            orderStatusTracker[orderId] = currentStatus;
            let colorClass = 'st-' + currentStatus.toLowerCase().split(' ')[0];
            if(currentStatus === 'Handed Over') colorClass = 'st-handed';
            const itemsHtml = o.items ? o.items.map(i => `<div style="display:flex; justify-content:space-between; font-size:13px; color:#666; margin-bottom:4px;"><span>${i.name} x ${i.qty}</span><span>₹${i.price * i.qty}</span></div>`).join('') : "";
            const totalLabel = currentLang === 'en' ? "Total" : "মোট";
            const subtotalLabel = currentLang === 'en' ? "Subtotal" : "সাবটোটাল";
            const delLabel = currentLang === 'en' ? "Delivery Fee" : "ডেলিভারি ফি";
            const driverHtml = (currentStatus === 'Handed Over' || currentStatus === 'Out for Delivery') && o.driverName ? `<div style="margin-top:10px; padding:12px; background:#e3f2fd; border-radius:12px; display:flex; justify-content:space-between; align-items:center;"><div><small style="display:block; font-size:10px; color:#1976d2; font-weight:700;">DELIVERY PARTNER</small><b style="font-size:14px;">${o.driverName}</b></div><a href="tel:${o.driverPhone}" style="width:35px; height:35px; background:#1976d2; color:white; border-radius:50%; display:flex; align-items:center; justify-content:center; text-decoration:none;"><i class="fas fa-phone-alt"></i></a></div>` : "";
            const mapId = `order-map-${orderId}`;
            const mapHtml = (currentStatus !== 'Delivered' && currentStatus !== 'Declined' && o.lat) ? `<div style="margin-top:10px;"><small style="font-weight:700; color:#888; font-size:10px;">DELIVERY LOCATION</small><p style="font-size:11px; color:#666; margin-bottom:5px;">${o.address}</p><div id="${mapId}" style="height:100px; width:100%; border-radius:12px; border:1px solid #eee; background:#f0f0f0;"></div></div>` : "";
            let surveyHtml = "";
            if(currentStatus === 'Delivered') {
                if(o.survey) {
                    let stars = "";
                    for(let s=1; s<=5; s++) stars += `<i class="fas fa-star" style="color:${s <= o.survey.rating ? 'var(--primary)' : '#ddd'}; font-size:14px; margin:0 2px;"></i>`;
                    surveyHtml = `<div class="survey-container submitted"><p class="survey-title">${langData[currentLang].survey_thanks}</p><div style="margin-bottom:5px;">${stars}</div><p style="font-size:11px; font-style:italic; color:#666;">"${o.survey.feedback || 'No comments'}"</p></div>`;
                } else {
                    surveyHtml = `<div class="survey-container" id="survey-${orderId}" data-selected="0"><p class="survey-title">${langData[currentLang].survey_q}</p><div class="stars-row"><i class="fas fa-star star-icon" onclick="setRating('${orderId}', 1)"></i><i class="fas fa-star star-icon" onclick="setRating('${orderId}', 2)"></i><i class="fas fa-star star-icon" onclick="setRating('${orderId}', 3)"></i><i class="fas fa-star star-icon" onclick="setRating('${orderId}', 4)"></i><i class="fas fa-star star-icon" onclick="setRating('${orderId}', 5)"></i></div><textarea id="feedback-${orderId}" class="feedback-input" placeholder="Any feedback for us? (Optional)"></textarea><button class="btn-survey" onclick="submitSurvey('${orderId}')">${langData[currentLang].survey_btn}</button></div>`;
                }
            }
            const pDisc = o.promoDiscount || o.discount || 0;
            const pDiscHtml = pDisc > 0 ? `<div style="display:flex; justify-content:space-between; font-size:11px; color:var(--success);"><span>Promo Discount</span><span>- ₹${pDisc}</span></div>` : '';
            const calculationHtml = `<div style="margin-top:10px; border-top:1px dashed #eee; padding-top:8px;"><div style="display:flex; justify-content:space-between; font-size:11px; color:#888;"><span>${subtotalLabel}</span><span>₹${o.subtotal || (o.total - (o.deliveryCharge || 0) + pDisc)}</span></div><div style="display:flex; justify-content:space-between; font-size:11px; color:var(--danger);"><span>${delLabel}</span><span>+ ₹${o.deliveryCharge || 0}</span></div>${pDiscHtml}<div style="display:flex; justify-content:space-between; font-weight:700; margin-top:5px; color:var(--primary); font-size:15px;"><span>${totalLabel}</span><span>₹${o.total}</span></div></div>`;
            const orderCard = `<div class="card" style="border-left: 5px solid ${currentStatus === 'Delivered' ? '#2e7d32' : 'var(--primary)'};"><div style="display:flex; justify-content:space-between;"><div><b>Order #${orderId.slice(-5)}</b><br><small style="color:#999">${d}</small></div><span class="status-pill ${colorClass}">${currentStatus}</span></div><div style="background:#f9f9f9; padding:10px; border-radius:12px; margin-top:10px;">${itemsHtml}${calculationHtml}</div>${driverHtml}${mapHtml}${surveyHtml}</div>`;
            if (currentStatus === 'Delivered' || currentStatus === 'Declined') {
                hc.innerHTML = orderCard + hc.innerHTML;
            } else {
                ac.innerHTML += orderCard;
                hasActive = true;
            }
            if(o.lat && currentStatus !== 'Delivered' && currentStatus !== 'Declined') {
                setTimeout(() => {
                    const mapDiv = document.getElementById(mapId);
                    if(mapDiv) {
                        try {
                            const m = new google.maps.Map(mapDiv, { center: {lat: o.lat, lng: o.lng}, zoom: 15, disableDefaultUI: true, gestureHandling: "none" });
                            new google.maps.Marker({ position: {lat: o.lat, lng: o.lng}, map: m });
                        } catch(e) { console.warn("Map error for order", orderId); }
                    }
                }, 500);
            }
        }); 
        if(!hasActive && ac.innerHTML === '') {
            ac.innerHTML = '<div class="card" style="text-align:center; color:#888;"><i class="fas fa-truck"></i><br>No active orders</div>';
        }
        isInitialLoad = false;
    }); 
}

function toggleHistory(){ const s = document.getElementById('history-section'); s.style.display = (s.style.display==='none')?'block':'none'; }
function enableEdit(id){ document.getElementById(id).readOnly=false; document.getElementById(id).disabled=false; document.getElementById(id).focus(); }
function saveProfile(){ 
    db.ref('users/' + auth.currentUser.uid).update({ name: document.getElementById('p-name').value, phone: document.getElementById('p-phone').value, age: document.getElementById('p-age').value, gender: document.getElementById('p-gender').value }).then(() => { alert("Profile Updated!"); }).catch(e => alert("Error: " + e.message));
}

function login(){ 
    const errDiv = document.getElementById('login-error');
    const btn = document.getElementById('ui-login-btn');
    const orig = btn.innerText;
    errDiv.style.display = 'none'; 
    btn.innerHTML = '<i class="fas fa-circle-notch fa-spin"></i> Processing...';
    btn.disabled = true;
    auth.signInWithEmailAndPassword(document.getElementById('l-email').value, document.getElementById('l-pass').value)
    .then(() => { btn.innerText = orig; btn.disabled = false; })
    .catch(e => {
        btn.innerText = orig; btn.disabled = false;
        let msg = "Invalid email or password. Please try again.";
        if(e.code === "auth/user-not-found") msg = "No account found with this email.";
        if(e.code === "auth/wrong-password") msg = "Incorrect password.";
        errDiv.innerText = msg; errDiv.style.display = 'block';
        if (navigator.vibrate) navigator.vibrate([50, 30, 50]);
    }); 
}

function googleLogin(){ 
    const btnText = document.getElementById('ui-google-login');
    const parentBtn = btnText.parentElement;
    const orig = btnText.innerText;
    btnText.innerHTML = "Processing...";
    parentBtn.disabled = true;
    auth.signInWithPopup(new firebase.auth.GoogleAuthProvider()).then(res => {
        db.ref('users/'+res.user.uid).once('value').then(snap => {
            if(!snap.exists()) {
                db.ref('users/'+res.user.uid).set({ 
                    name: res.user.displayName || "Google User", phone: "", address: "", age: "", gender: "Male", email: res.user.email || "", orderCount: 0
                });
            }
        });
        btnText.innerText = orig; parentBtn.disabled = false;
    }).catch(e => { btnText.innerText = orig; parentBtn.disabled = false; alert(e.message); });
}

function register(){ 
    const name = document.getElementById('r-name').value;
    const phone = document.getElementById('r-phone').value;
    const pass = document.getElementById('r-pass').value;
    let email = document.getElementById('r-email').value;
    if(!name || !phone || !pass) return alert("Please fill all mandatory fields (Name, Phone, Password)");
    if(!/^\d{10}$/.test(phone)) return alert("Please enter a valid 10-digit phone number");
    if(!email) email = phone + "@chachumuk.com";
    const btn = document.getElementById('ui-reg-btn');
    const orig = btn.innerText;
    btn.innerHTML = '<i class="fas fa-circle-notch fa-spin"></i> Processing...';
    btn.disabled = true;
    auth.createUserWithEmailAndPassword(email, pass).then(res => { 
        db.ref('users/'+res.user.uid).set({ 
            name: name, phone: phone, address: "", age: "", gender: "Male", email: document.getElementById('r-email').value || "", orderCount: 0
        }).then(() => { btn.innerText = orig; btn.disabled = false; }); 
    }).catch(e => { btn.innerText = orig; btn.disabled = false; alert(e.message); }); 
}

function closePromoPopup() {
    document.getElementById('promo-popup-overlay').style.display = 'none';
}

function triggerGlobalPromoPopup() {
    if(globalPromoFired) return;
    db.ref('promocode/live').once('value', snap => {
        const promos = snap.val();
        if(!promos) return;
        for (const code in promos) {
            const p = promos[code];
            if (p.poster_url) {
                document.getElementById('promo-popup-img').src = p.poster_url;
                document.getElementById('promo-popup-overlay').style.display = 'flex';
                globalPromoFired = true;
                break;
            }
        }
    });
}

// --- DOMContentLoaded and auth state listener ---

document.addEventListener('DOMContentLoaded', () => {
    // Loader animation handling (the original loader scripts are in HTML but we keep them there)
    // We'll just initialize things.
    if(!localStorage.getItem('appLang')) setTimeout(openLangModal, 5000);
    
    // Haptic feedback for touch
    document.addEventListener('touchstart', function(e) {
        const hapticSelectors = 'button, .nav-item, .star-icon, .btn-add, .contact-btn, .contact-opt, .qty-box button, .prof-edit, .pay-opt, .addr-opt-btn, .saved-addr-card';
        if (e.target.closest(hapticSelectors)) { if (navigator.vibrate) navigator.vibrate(40); }
    }, { passive: true });
});

// Auth state listener
auth.onAuthStateChanged(user => {
    if(user) {
        isGuest = false;
        closeAuthModals();
        document.getElementById('main-nav').style.display = 'flex';
        db.ref('users/' + user.uid).on('value', s => {
            userData = s.val() || {};
            if (userData.orderCount === undefined) userData.orderCount = 0;
            const prefix = currentLang === 'en' ? "Welcome" : "স্বাগতম";
            document.getElementById('welcome-user-span').innerText = prefix + ", " + (userData.name || "User") + "!";
            document.getElementById('user-initials').innerText = (userData.name || "U").charAt(0).toUpperCase();
            document.getElementById('p-name').value = userData.name || "";
            document.getElementById('p-phone').value = userData.phone || "";
            document.getElementById('p-age').value = userData.age || "";
            document.getElementById('p-gender').value = userData.gender || "Male";
            if (document.getElementById('checkout-page').classList.contains('active')) renderCheckoutTotals();
        });
        db.ref('settings/open_time').on('value', s => { shopOpenTimeStr = s.val() || '10:00'; updateShopClosedUI(); });
        db.ref('settings/close_time').on('value', s => { shopCloseTimeStr = s.val() || '22:00'; updateShopClosedUI(); });
        db.ref('settings/is_open').on('value', snap => {
            shopIsOpen = snap.val() !== false; 
            if(document.getElementById('home-page').classList.contains('active')) renderMenu();
            if(document.getElementById('checkout-page').classList.contains('active')) renderCheckoutTotals();
        });
        changeLang(currentLang); 
        saveCart(); 
        if(document.getElementById('login-modal').style.display === 'flex' || !document.querySelector('.page.active')) {
            showPage('home-page');
        }
        cycleSearchHints();
    } else { 
        isGuest = true;
        document.getElementById('main-nav').style.display = 'none';
        document.getElementById('welcome-user-span').innerText = "Welcome, Guest!";
        db.ref('settings/open_time').on('value', s => { shopOpenTimeStr = s.val() || '10:00'; updateShopClosedUI(); });
        db.ref('settings/close_time').on('value', s => { shopCloseTimeStr = s.val() || '22:00'; updateShopClosedUI(); });
        db.ref('settings/is_open').on('value', snap => {
            shopIsOpen = snap.val() !== false; 
            if(document.getElementById('home-page').classList.contains('active')) renderMenu();
        });
        showPage('home-page'); 
        document.getElementById('global-header').style.display = 'block'; 
    }
});

// Additional initializer for loader and global promo (keeping from original)
setTimeout(triggerGlobalPromoPopup, 5000);