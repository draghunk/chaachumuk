// assets/js/driver.js
// Driver partner logic

// --------------------------------------------------------------
// SCREEN MANAGEMENT (with anti‑recursion lock)
// --------------------------------------------------------------
let isSwitching = false;
let currentScreen = null;

window.switchScreen = function(id) {
    if (isSwitching) {
        console.warn('switchScreen blocked: already switching');
        return;
    }
    if (currentScreen === id) {
        console.log('Already on screen:', id);
        return;
    }

    isSwitching = true;

    try {
        document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
        const target = document.getElementById(id);
        if (target) {
            target.classList.add('active');
            currentScreen = id;
        } else {
            console.error('Screen not found:', id);
        }

        const loader = document.getElementById('loader-wrapper');
        if (loader && loader.style.display !== 'none') {
            loader.style.opacity = '0';
            setTimeout(() => {
                loader.style.display = 'none';
            }, 800);
        }
    } catch (e) {
        console.error('switchScreen error:', e);
    } finally {
        setTimeout(() => {
            isSwitching = false;
        }, 200);
    }
};

// --------------------------------------------------------------
// GLOBALS AND GEOLOCATION
// --------------------------------------------------------------
const ringer = document.getElementById('ringer');
let userLat = 0, userLng = 0, currentUID = null, allOrdersData = null;
let driverProfile = null;

navigator.geolocation.watchPosition(p => {
    userLat = p.coords.latitude;
    userLng = p.coords.longitude;
    renderOrders();
}, e => {}, { enableHighAccuracy: true });

function getDistance(lat1, lon1, lat2, lon2) {
    const R = 6371e3;
    const d1 = lat1 * Math.PI / 180, d2 = lat2 * Math.PI / 180;
    const dd = (lat2 - lat1) * Math.PI / 180, dl = (lon2 - lon1) * Math.PI / 180;
    const a = Math.sin(dd / 2) ** 2 + Math.cos(d1) * Math.cos(d2) * Math.sin(dl / 2) ** 2;
    return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

// --------------------------------------------------------------
// FIREBASE AUTH & DRIVER DATA (now using once)
// --------------------------------------------------------------
auth.onAuthStateChanged(user => {
    if (user) {
        currentUID = user.uid;
        // Use once() to get driver data – no risk of null initial callback
        db.ref('drivers/' + user.uid).once('value').then(snap => {
            const d = snap.val();
            if (!d) {
                window.switchScreen('screen-register');
            } else if (d.status !== 'approved') {
                window.switchScreen('screen-pending');
            } else {
                window.switchScreen('screen-app');
                driverProfile = d;
                loadProfile(d);
                // Now attach persistent listeners for profile updates and orders
                attachDriverListener(user.uid);
                syncOrders();
            }
        }).catch(err => {
            console.error('Error reading driver data:', err);
            window.switchScreen('screen-login'); // fallback
        });
    } else {
        window.switchScreen('screen-login');
    }
});

// Attach persistent listener for profile changes (optional)
function attachDriverListener(uid) {
    db.ref('drivers/' + uid).on('value', snap => {
        const d = snap.val();
        if (d && d.status === 'approved') {
            driverProfile = d;
            loadProfile(d);
        }
    });
}

// --------------------------------------------------------------
// LOGIN / REGISTER
// --------------------------------------------------------------
function handleLogin() {
    const e = document.getElementById('login-email').value,
        p = document.getElementById('login-pass').value;
    document.getElementById('login-error').style.display = 'none';
    auth.signInWithEmailAndPassword(e, p)
        .catch(() => document.getElementById('login-error').style.display = 'block');
}

function handleRegister() {
    const f = {
        name: document.getElementById('r-name').value,
        phone: document.getElementById('r-phone').value,
        email: document.getElementById('r-email').value,
        address: document.getElementById('r-addr').value,
        dob: document.getElementById('r-dob').value,
        blood: document.getElementById('r-blood').value,
        edu: document.getElementById('r-edu').value,
        license: document.getElementById('r-license').value,
        adhar: document.getElementById('r-adhar').value,
        pass: document.getElementById('r-pass').value
    };
    if (Object.values(f).some(v => !v) || !document.getElementById('r-agree').checked) {
        alert("All fields are mandatory");
        return;
    }
    auth.createUserWithEmailAndPassword(f.email, f.pass)
        .then(u => {
            delete f.pass;
            f.status = 'pending';
            db.ref('drivers/' + u.user.uid).set(f);
        })
        .catch(err => alert(err.message));
}

// --------------------------------------------------------------
// ORDER SYNC & RENDERING
// --------------------------------------------------------------
function syncOrders() {
    db.ref('orders').on('value', snap => {
        allOrdersData = snap;
        renderOrders();
    });
}

function renderOrders() {
    if (!allOrdersData || !currentUID) return;
    const live = document.getElementById('live-container'),
        hist = document.getElementById('history-container');
    const dateFilter = document.getElementById('history-date-filter').value;
    live.innerHTML = "";
    hist.innerHTML = "";
    let playRinger = false,
        totalEarnings = 0;

    allOrdersData.forEach(child => {
        const o = child.val();
        if (o.driverId !== currentUID) return;
        const id = child.key;
        const orderDate = new Date(o.timestamp).toISOString().split('T')[0];
        if (o.status === 'Handed Over') {
            if (!o.driverAccepted) playRinger = true;
            live.innerHTML += buildOrderCard(id, o, getDistance(userLat, userLng, o.lat, o.lng), true);
        } else if (o.status === 'Delivered') {
            if (!dateFilter || dateFilter === orderDate) {
                totalEarnings += parseFloat(o.deliveryCharge || 0);
                hist.innerHTML = buildOrderCard(id, o, 0, false) + hist.innerHTML;
            }
        }
    });
    document.getElementById('total-delivery-earnings').innerText = "₹" + totalEarnings;
    if (playRinger) {
        ringer.play().catch(() => {});
    } else {
        ringer.pause();
        ringer.currentTime = 0;
    }
    if (!live.innerHTML) {
        live.innerHTML = "<center style='margin-top:80px; color:#ccc;'><i class='fas fa-box-open fa-3x'></i><p style='margin-top:10px'>No active orders</p></center>";
    }
}

function buildOrderCard(id, o, dist, isLive) {
    let itemsMarkup = "";
    if (o.items) o.items.forEach(i => itemsMarkup += `<div class="item-row"><span>${i.name} x${i.qty}</span><span>₹${i.price*i.qty}</span></div>`);
    return `<div class="card"><div style="display:flex; justify-content:space-between"><b>Order #${id.slice(-5)}</b><small style="font-weight:600; color:${o.status==='Delivered'?'green':'var(--primary)'}">${o.status.toUpperCase()}</small></div><p style="font-size:13px; margin:8px 0;"><b>Customer:</b> ${o.customerName}<br><b>Loc:</b> ${o.address}<br><b>Payment:</b> ${o.paymentmethod || 'N/A'}</p><div class="order-box">${itemsMarkup}<hr style="margin:8px 0; border:none; border-top:1px solid #eee;"><div class="item-row"><span>Delivery Fee</span><span>₹${o.deliveryCharge || 0}</span></div><div class="item-row" style="font-weight:700; color:var(--success); font-size:14px;"><span>Grand Total</span><span>₹${o.total}</span></div></div>${isLive ? (o.driverAccepted ? `<button class="btn btn-call" onclick="window.location.href='tel:${o.customerPhone}'"><i class="fas fa-phone"></i> Call Customer</button><button class="btn btn-nav" onclick="window.open('https://www.google.com/maps?q=${o.lat},${o.lng}')"><i class="fas fa-location-arrow"></i> Navigate</button>${dist < 100 ? `<button class="btn btn-success" onclick="db.ref('orders/${id}').update({status:'Delivered'})">Mark Delivered</button>` : `<p style="font-size:10px; color:red; text-align:center; margin-top:10px;">Reach within 100m (Current: ${Math.round(dist)}m)</p>`}` : `<button class="btn btn-primary" onclick="acceptOrder('${id}')">Accept Assignment</button><button class="btn btn-nav" onclick="window.open('https://www.google.com/maps?q=${o.lat},${o.lng}')">View Map</button>`) : `<small style="color:#aaa;">Delivered on: ${new Date(o.timestamp).toLocaleString()}</small>`}</div>`;
}

function clearFilter() {
    document.getElementById('history-date-filter').value = "";
    renderOrders();
}

function acceptOrder(id) {
    navigator.geolocation.getCurrentPosition(() => {
        db.ref('orders/' + id).update({ driverAccepted: true });
        alert("Order Accepted!");
    }, () => alert("Location permission required."));
}

function switchTab(id, el) {
    document.querySelectorAll('.tab-content').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
    document.getElementById(id).classList.add('active');
    el.classList.add('active');
    document.getElementById('refresh-trigger').style.display = (id === 'tab-live') ? 'block' : 'none';
}

function loadProfile(d) {
    document.getElementById('p-name').innerText = d.name;
    document.getElementById('p-phone').innerText = d.phone;
    document.getElementById('p-email').innerText = d.email;
    document.getElementById('p-adhar').innerText = d.adhar;
    document.getElementById('p-license').innerText = d.license;
    document.getElementById('p-blood').innerText = d.blood;
}

function refreshLiveOrders() {
    const btn = document.getElementById('refresh-trigger');
    btn.classList.add('spin-anim');
    setTimeout(() => btn.classList.remove('spin-anim'), 800);
    navigator.geolocation.getCurrentPosition(p => {
        userLat = p.coords.latitude;
        userLng = p.coords.longitude;
        renderOrders();
    }, e => {
        renderOrders();
    }, { enableHighAccuracy: true });
}

// Haptics
document.addEventListener('pointerdown', function(e) {
    const target = e.target.closest('button, .nav-item, .btn, a, #refresh-trigger');
    if (target && window.navigator && window.navigator.vibrate) {
        window.navigator.vibrate(40);
    }
}, { passive: true });

// Expose functions globally
window.handleLogin = handleLogin;
window.handleRegister = handleRegister;
window.acceptOrder = acceptOrder;
window.clearFilter = clearFilter;
window.renderOrders = renderOrders;
window.refreshLiveOrders = refreshLiveOrders;
window.switchTab = switchTab;