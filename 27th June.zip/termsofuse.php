<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover">
    <title>Terms of Use | Cha A Chumuk</title>
    <link rel="icon" type="image/x-icon" href="favicon.ico">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@700&family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
    <style>
        :root { --primary: #ff9f1c; --primary-grad: linear-gradient(135deg, #ff9f1c 0%, #ff5e00 100%); --bg: #f8f9fa; --danger: #ff4757; --success: #2e7d32; --blue-accent: #5d87d6; }
        * { box-sizing: border-box; margin: 0; padding: 0; -webkit-tap-highlight-color: transparent; }
        body { font-family: 'Poppins', sans-serif; background: var(--bg); color: #333; overflow-x: hidden; }

        /* HEADER UI */
        .home-header { background: var(--primary-grad); padding: 30px 20px 20px 20px; color: white; border-radius: 0 0 35px 35px; position: fixed; top: 0; left: 0; width: 100%; z-index: 998; box-shadow: 0 4px 15px rgba(0,0,0,0.1); display: flex; align-items: center; gap: 15px; }
        .back-btn { background: rgba(255,255,255,0.2); width: 38px; height: 38px; border-radius: 50%; display: flex; align-items: center; justify-content: center; border: 1px solid white; color: white; cursor: pointer; text-decoration: none; transition: 0.2s; }
        .back-btn:active { transform: scale(0.9); }
        .header-title { font-family: 'Montserrat', sans-serif; font-size: 18px; font-weight: 700; }

        /* CONTENT UI */
        .page-content { padding-top: 110px; padding-bottom: 40px; }
        .card { background: white; border-radius: 20px; padding: 25px; margin: 15px; box-shadow: 0 4px 12px rgba(0,0,0,0.05); position: relative; }
        
        /* TYPOGRAPHY */
        h2 { font-size: 20px; color: var(--primary); margin-bottom: 15px; font-family: 'Montserrat', sans-serif; text-align: center; }
        h3 { font-size: 15px; color: #222; margin-top: 20px; margin-bottom: 8px; font-weight: 600; display: flex; align-items: center; gap: 8px; }
        h3 i { color: var(--primary); font-size: 14px; }
        p, li { font-size: 13px; color: #555; line-height: 1.7; margin-bottom: 10px; }
        ul { padding-left: 20px; margin-bottom: 15px; }
        li { margin-bottom: 5px; }
        .last-updated { text-align: center; font-size: 11px; color: #999; margin-bottom: 20px; font-weight: 600; text-transform: uppercase; letter-spacing: 1px; }
        
        hr { border: none; border-top: 1px dashed #eee; margin: 20px 0; }
    </style>
</head>
<body>

    <!-- STICKY HEADER -->
    <div class="home-header">
        <a href="javascript:history.back()" class="back-btn"><i class="fas fa-arrow-left"></i></a>
        <div style="display:flex; align-items:center; gap:12px;">
            <img src="logo.png" alt="Logo" style="width:35px; border-radius:50%; background:white; padding: 2px;">
            <div class="header-title">Cha A Chumuk</div>
        </div>
    </div>

    <div class="page-content">
        <div class="card">
            <h2>Terms of Use</h2>
            <div class="last-updated">Last Updated: May 2026</div>

            <p>By accessing or using the <b>Cha A Chumuk</b> application, you agree to comply with and be bound by the following Terms of Use. Please read them carefully before placing an order.</p>

            <h3><i class="fas fa-user-circle"></i> 1. Account & Registration</h3>
            <p>Guest browsing is permitted, but placing an order requires mandatory login or registration. You are responsible for providing an accurate 10-digit mobile number and address details to ensure successful delivery. Providing false information may result in order cancellation and account suspension.</p>

            <h3><i class="fas fa-motorcycle"></i> 2. Delivery & Radius Policy</h3>
            <ul>
                <li>We deliver exclusively within a <b>15 kilometer</b> radius of our restaurant coordinate location.</li>
                <li>If your pinned location or saved address exceeds this limit, the system will prevent the checkout process.</li>
                <li>Delivery fees are calculated dynamically based on real-time road distance.</li>
                <li>Specific distance slabs have a <b>Minimum Order Requirement</b>. You must meet this cart value to proceed to checkout.</li>
            </ul>

            <h3><i class="fas fa-rupee-sign"></i> 3. Pricing & Payments</h3>
            <p>All prices listed on the menu are subject to change without prior notice. The items in your cart will auto-update to reflect current pricing. We accept:</p>
            <ul>
                <li><b>Online Payments:</b> Secured through Razorpay.</li>
                <li><b>Cash on Delivery (COD):</b> Payment must be made in full (via cash or UPI) to the delivery partner upon arrival.</li>
            </ul>

            <h3><i class="fas fa-ban"></i> 4. Cancellations & Refunds</h3>
            <p>Orders once placed and accepted by the restaurant cannot be cancelled from the user's end. If an online payment fails but money is deducted from your account, Razorpay will initiate an automatic refund to the source account within 5-7 business days.</p>

            <h3><i class="fas fa-exclamation-triangle"></i> 5. Location Services</h3>
            <p>Our app requires GPS/Location access to plot your delivery accurately on the map. You must grant location permissions to use the 'Current Location' feature seamlessly during checkout.</p>

            <hr>
            <p style="text-align: center; font-weight: 600; color: #888; font-size: 12px;">By continuing to use Cha A Chumuk, you acknowledge that you have read and understood these terms.</p>
        </div>
    </div>

    <script>
        // Haptic feedback for back button
        document.querySelector('.back-btn').addEventListener('touchstart', function() {
            if (navigator.vibrate) navigator.vibrate(40);
        }, { passive: true });
    </script>
</body>
</html>