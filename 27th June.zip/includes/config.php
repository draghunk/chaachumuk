<?php
// includes/config.php

// Firebase
define('FB_API_KEY', "AIzaSyAmKXMQy_PQmtC6us4INrEk-eS6i-yeLnQ");
define('FB_DB_URL', "https://cacf-d3b74-default-rtdb.firebaseio.com");
define('FB_PROJ_ID', "cacf-d3b74");

// Razorpay
define('RZP_KEY_ID', "rzp_live_SmOKAPM9jeBpYH");
define('RZP_KEY_SECRET', "iJt0UhpFjBhLEtu4YD9pXXuZ");

// Google Maps
define('GOOGLE_MAPS_API_KEY', "AIzaSyDTj-DJsIyPlpWGwCeCB03Fr-7mEPTY1Mg");

// Optional: base URL for assets (if you need)
define('BASE_URL', '');
?>